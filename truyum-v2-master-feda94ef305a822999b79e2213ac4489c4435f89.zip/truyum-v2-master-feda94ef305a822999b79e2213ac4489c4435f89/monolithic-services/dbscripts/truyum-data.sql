-- Include table data insertion, updation, deletion and select scripts
show tables;

-- SQL query to insert into menu items.
insert into  menu_item(me_name,me_price,me_active,me_date_of_launch,me_category,me_free_delivery)
 values("Burger", 129.00, true, '2017-12-23', "Main Course",
					false);          
                    insert into  menu_item(me_name,me_price,me_active,me_date_of_launch,me_category,me_free_delivery)
 values("Sandwich", 99.00, true,'2017-03-15', 
				"Main Course", true);
               
               
insert into  menu_item(me_name,me_price,me_active,me_date_of_launch,me_category,me_free_delivery)
 values( "Pizza", 149.00, true,'2018-08-21', "Main Course",
					false  ); 
insert into  menu_item(me_name,me_price,me_active,me_date_of_launch,me_category,me_free_delivery)
 values( "French Fries", 57.00, false,'2017-07-02',
					"Starters", true );     
insert into  menu_item(me_name,me_price,me_active,me_date_of_launch,me_category,me_free_delivery)
 values( "Chocolate Brownie", 32.00, true,'2022-11-02',
					"Dessert", true ); 
                    
-- SQL query to get all menu items
select * from menu_item;

-- SQL query to get all menu items which are after launch date and is active.
select *  from menu_item where me_active='1' and  me_date_of_launch < curdate();

delete from menu_item where me_id=3;
update menu_item set me_id=3 where me_id=4;
update menu_item set me_id=4 where me_id=5;
update menu_item set me_id=5 where me_id=6;

-- SQL query to get a menu item based on Menu Item Id
select * from menu_item where me_id=2;

-- Update SQL menu_item table to update all the columns values based on Menu Item Id
update menu_item set me_name='Water Balls',me_price=20.00,me_active='No',
me_date_of_launch='2017-09-12',me_category='Starters',me_free_delivery='No' where me_id=5;

-- SQL query to insert two users into user table.
insert into user(us_id,us_name)values(101,'User_1'),(102,'User_2');

insert into cart(ct_us_id,ct_pr_id)values(101,1),(101,3),(101,4);

-- SQL query to get all menu items in a particular user’s cart
select me_name,me_price,me_active,me_date_of_launch,me_category,me_free_delivery from cart 
left join menu_item on ct_pr_id=me_id where ct_us_id=101;

-- SQL query to get the total price of all menu items in a particular user’s cart
select sum(me_price) from cart 
left join menu_item on ct_pr_id=me_id where ct_us_id=101;

-- SQL query to remove a menu item from Cart based on User Id and Menu Item Id	
delete from cart where ct_us_id=101 and ct_pr_id=4;

update menu_item set me_active=true and me_free_delivery=false where me_id=5;

update menu_item set me_free_delivery=false where me_id=5;
select * from menu_item;

use truyum;
update menu_item set me_active='Yes' where me_id=1;
update menu_item set me_active='Yes' where me_id=2;
update menu_item set me_active='Yes' where me_id=3;
update menu_item set me_active='No' where me_id=4;
update menu_item set me_active='Yes' where me_id=5;
update menu_item set me_free_delivery='Yes' where me_id=1;
update menu_item set me_free_delivery='Yes' where me_id=2;
update menu_item set me_free_delivery='No' where me_id=3;
update menu_item set me_free_delivery='Yes' where me_id=4;
update menu_item set me_free_delivery='No' where me_id=5;

       