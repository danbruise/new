-- Include table data insertion, updation, deletion and select scripts

use final_check;

-- SQL query to insert into movie items.
insert into movie_item(mo_title,mo_boxOffice,mo_active,mo_date_of_launch,mo_genre,mo_hasTeaser)
values('Avatar',2787965087.00, 'Yes', '2017-03-15','Science Fiction', 'Yes');


insert into movie_item(mo_title,mo_boxOffice,mo_active,mo_date_of_launch,mo_genre,mo_hasTeaser)
values('The Avengers', '1518812988', 'Yes','2017-12-23','Superhero', 'No');

insert into movie_item(mo_title,mo_boxOffice,mo_active,mo_date_of_launch,mo_genre,mo_hasTeaser)
values('Titanic', 2187463944,'Yes','2018-08-21', 'Romance','No');


insert into movie_item(mo_title,mo_boxOffice,mo_active,mo_date_of_launch,mo_genre,mo_hasTeaser)
values('Jurassic World', 1671713208, 'No','2017-07-02','Science Fiction', 'Yes');


insert into movie_item(mo_title,mo_boxOffice,mo_active,mo_date_of_launch,mo_genre,mo_hasTeaser)
values('Avengers:End Game', 2750760348, 'Yes','2022-11-02','Superhero', 'Yes');

-- SQL query to get all movie items
select * from movie_item;

-- SQL query to get all movie items which are after launch date and is active.
select *  from movie_item where mo_active='Yes' and  mo_date_of_launch < curdate();

-- SQL query to get a movie item based on Movie Item Id
select * from movie_item where mo_id=2;

-- Update SQL movie_item table to update all the columns values based on Movie Item Id
update movie_item set mo_title='Battle of Los Angeles',mo_boxOffice=2345637890.00,mo_active='No',
mo_date_of_launch='2017-10-12',mo_genre='Action',mo_hasTeaser='No' where mo_id=5;


select * from movie_item;

-- SQL query to insert two users into user table.
insert into user(us_id,us_name)values(101,'User_1'),(102,'User_2');

insert into favorites(f_us_id,f_pr_id)values(101,1),(101,3),(101,4);

-- SQL query to get all movie items in a particular user’s cart 
select mo_title,mo_boxOffice,mo_active,mo_date_of_launch,mo_genre,mo_hasTeaser from favorites
left join movie_item on f_pr_id=mo_id where f_us_id=101;

-- SQL query to get the total price of all movie items in a particular user’s cart
select sum(mo_boxOffice) from favorites
left join movie_item on f_pr_id=mo_id where f_us_id=101;

-- SQL query to remove a movie item from Cart based on User Id and Movie Item Id	
delete from favorites where f_us_id=101 and f_pr_id=4;

select * from movie_item;

