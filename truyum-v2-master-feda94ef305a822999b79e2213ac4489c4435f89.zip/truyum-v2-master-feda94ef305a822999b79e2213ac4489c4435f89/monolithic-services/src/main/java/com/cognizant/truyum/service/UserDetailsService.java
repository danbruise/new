package com.cognizant.truyum.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.cognizant.truyum.ResponseTransfer;
import com.cognizant.truyum.controller.UserController;
import com.cognizant.truyum.dao.UserAlreadyExistsException;
import com.cognizant.truyum.model.Role;
import com.cognizant.truyum.model.User;
import com.cognizant.truyum.repository.UserRepository;

@Service
public class UserDetailsService {
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	UserRepository userRepository;

	@Transactional
	public User findByUserName(String username) {
		// System.err.println("username: "+username);
		return userRepository.findAllByUserName(username);

	}

	@Transactional
	public ResponseTransfer signup(User user) throws UserAlreadyExistsException {

		User username = userRepository.findAllByUserName(user.getUsername());
		// System.err.println("Username in service: "+username);
		logger.debug("signup method");
		if (username == null) {
			// System.err.println("saving new user");
			BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
			String encodedPassword = bCryptPasswordEncoder.encode(user.getPassword());
			List<Role> roles = new ArrayList<Role>();
			roles.add(new Role(1, "ROLE_USER"));
			User newUser = new User(0, user.getUsername(), encodedPassword, roles);
			userRepository.save(newUser);
		}

		else
			throw new UserAlreadyExistsException();

		// System.err.println("Username: "+username);

		return new ResponseTransfer("successfully added");
	}
}
