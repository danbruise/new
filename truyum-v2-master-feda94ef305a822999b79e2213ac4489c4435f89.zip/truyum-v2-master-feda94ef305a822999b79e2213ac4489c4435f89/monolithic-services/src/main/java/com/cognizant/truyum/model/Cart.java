package com.cognizant.truyum.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "cart")
public class Cart {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ct_id")
	private int ct_id;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "cart", joinColumns = { @JoinColumn(name = "ct_us_id") }, inverseJoinColumns = {
			@JoinColumn(name = "ct_pr_id") })
	private Set<MenuItem> menuItem;

	// private double total;

	public int getCt_id() {
		return ct_id;
	}

	public void setCt_id(int ct_id) {
		this.ct_id = ct_id;
	}

	public Set<MenuItem> getMenuItem() {
		return menuItem;
	}

	public void setMenuItem(Set<MenuItem> menuItem) {
		this.menuItem = menuItem;
	}

	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cart(int ct_id, Set<MenuItem> menuItem) {// , double total
		super();
		this.ct_id = ct_id;
		this.menuItem = menuItem;
		// this.total = total;
	}

	@Override
	public String toString() {
		return "Cart [ct_id=" + ct_id + ", menuItem=" + menuItem + "]"; // ",
																		// total="
																		// +
																		// total
																		// +
	}

	// public double getTotal() {
	// return total;
	// }
	//
	// public void setTotal(double total) {
	// this.total = total;
	// }

}
