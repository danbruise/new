//package com.cognizant.truyum.dao;
//
//import java.text.DateFormat;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Calendar;
//import java.util.Date;
//import java.util.List;
//
//
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.support.ClassPathXmlApplicationContext;
//import org.springframework.stereotype.Component;
//
//import com.cognizant.truyum.util.DateUtil;
//
//import com.cognizant.truyum.model.MenuItem;
//@Component
//public class MenuItemDaoCollectionImpl implements MenuItemDao {
//
//	private static List<MenuItem> menuItemList; // menuItemList is private
//												// static method of List type
//
//	public MenuItemDaoCollectionImpl() {
//
///*		if (menuItemList == null) {
//			// initialize menuItemList
//			menuItemList = new ArrayList<MenuItem>();
//			MenuItem itemSandwich = new MenuItem(1, "Sandwich", 99.00f, true, DateUtil.convertToDate("15/03/2017"),
//					"Main Course", true);
//			MenuItem itemBurger = new MenuItem(2, "Burger", 129.00f, true, DateUtil.convertToDate("23/12/2017"),
//					"Main Course", false);
//			MenuItem itemPizza = new MenuItem(3, "Pizza", 149.00f, true, DateUtil.convertToDate("21/08/2018"),
//					"Main Course", false);
//			MenuItem itemFries = new MenuItem(4, "French Fries", 57.00f, false, DateUtil.convertToDate("02/07/2017"),
//					"Starters", true);
//			MenuItem itemBrowine = new MenuItem(5, "Chocolate Browine", 32.00f, true,
//					DateUtil.convertToDate("02/11/2022"), "Dessert", true);
//
//			menuItemList.add(itemSandwich);
//			menuItemList.add(itemBurger);
//			menuItemList.add(itemPizza);
//			menuItemList.add(itemFries);
//			menuItemList.add(itemBrowine);
//
//		}
//*/
//		
//		ApplicationContext context=new ClassPathXmlApplicationContext("truyum.xml");
//		menuItemList=context.getBean("menuList",List.class);
//		
////		for (MenuItem menuItem : menuItemList) {
////			System.out.println("---"+menuItem);
////		}
//		
//	}
//
//	@Override
//	public List<MenuItem> getMenuItemListAdmin() {
//		// TODO Auto-generated method stub
//		return menuItemList;
//	}
//
//	@Override
//	public List<MenuItem> getMenuItemListCustomer() {
//		// TODO Auto-generated method stub
//
//		ArrayList<MenuItem> menuItemListFilter = new ArrayList<MenuItem>();
//		Date date = Calendar.getInstance().getTime();
//		DateFormat dateFormat = new SimpleDateFormat("dd/mm/yyyy");
//		String strdate = dateFormat.format(date);
//		Date d = DateUtil.convertToDate(strdate);
//
//		// Converting the date in proper format
//
//		for (MenuItem menuItem : menuItemList) {
//			if ((menuItem.getdateOfLaunch().equals(d) || menuItem.getdateOfLaunch().before(d))
//					&& menuItem.isActive() == true) {
//				menuItemListFilter.add(menuItem);
//
//			}
//		}
//
//		// returning filtered menuItemList
//		return menuItemListFilter;
//	}
//
//	@Override
//	public void maodifyMenuItem(MenuItem menuItem) {
//		// TODO Auto-generated method stub
//
////		for (MenuItem menuItemfromList : menuItemList) {
////			if (menuItemfromList.equals(menuItem)) {
////				{
////
////					menuItemfromList.setName(menuItem.getName());
////					menuItemfromList.setPrice(menuItem.getPrice());
////					menuItemfromList.setActive(menuItem.isActive());
////					menuItemfromList.setCategory(menuItem.getCategory());
////					menuItemfromList.setdateOfLaunch(menuItem.getdateOfLaunch());
////					menuItemfromList.setFreeDelivery(menuItem.isFreeDelivery());
////					break;
////				}
////			}
////		}
//
////	menuItemList.set((int) menuItem.getId()-1, menuItem);	
//
//	}
//
//	@Override
//	public MenuItem getMenuItem(long menuItemId) {
//		// TODO Auto-generated method stub
//
//		for (MenuItem menuItemIdfromList : menuItemList) {
////			if (menuItemIdfromList.getId() == (menuItemId)) {
////				{
////					return menuItemIdfromList;
////				}
////			}
//		}
//		return null;
//	}
//
//}
