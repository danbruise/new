package com.cognizant.truyum.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.truyum.ResponseTransfer;
import com.cognizant.truyum.dao.UserAlreadyExistsException;
//import com.cognizant.truyum.dao.UserAlreadyExistsException;
import com.cognizant.truyum.model.User;
import com.cognizant.truyum.repository.UserRepository;
import com.cognizant.truyum.service.UserDetailsService;


@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/users")
public class UserController {
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

//	@Autowired
//	private InMemoryUserDetailsManager inMemoryUserDetailsManager;
	
//	@Autowired
//	AppUserDetailsService appService;
	
	@Autowired
	UserDetailsService userDetailsService;
	
	@Autowired
	UserRepository userRepository;

//	@PostMapping("")
//	public boolean signup(@RequestBody @Valid User user) throws UserAlreadyExistsException {
//		System.out.println("User Details !!!!!"+user.toString());
//		
//		if (inMemoryUserDetailsManager.userExists(user.getUsername())) {
//			
//			throw new UserAlreadyExistsException();
//		} else {
//            inMemoryUserDetailsManager.createUser(org.springframework.security.core.userdetails.User.withUsername(user.getUsername())
//            .password(new BCryptPasswordEncoder().encode(user.getPassword()))
//            .roles("USER").build());
//
//			System.out.println("--new user ====>");
//			return true;
//
//		}
//	}
	@GetMapping("/{username}")
	public User userDetails(@PathVariable String username)
	{
		logger.debug("Start retrieving user details");
		logger.debug("End retrieving user details");

		return userDetailsService.findByUserName(username);
	}
	
	@PostMapping("")
	public ResponseTransfer signUpController(@RequestBody User user) throws UserAlreadyExistsException
	{
		logger.debug("in signup controller");

		return userDetailsService.signup(user);
	}
}
