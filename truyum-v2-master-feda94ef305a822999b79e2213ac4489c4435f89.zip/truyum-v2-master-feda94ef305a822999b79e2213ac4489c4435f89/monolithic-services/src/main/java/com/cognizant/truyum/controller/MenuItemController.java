package com.cognizant.truyum.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.truyum.ResponseTransfer;
import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.security.AppUserDetailsService;
import com.cognizant.truyum.service.MenuItemService;

@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/menu-items")
public class MenuItemController {
	private static final Logger logger = LoggerFactory.getLogger(AuthenticationController.class);
	@Autowired
	private MenuItemService menuItemService;
	// private static final Logger logger =
	// LoggerFactory.getLogger(AuthenticationController.class);

	// @GetMapping("/active")
	// public Set<MenuItem> isActiveController()
	// {
	// return menuItemService.isActiveSevice();
	//
	// }

	@GetMapping("/admin")
	public List<MenuItem> adminController() {
		return menuItemService.getMenuItemListAdmin();

	}

	// @Autowired
	// private InMemoryUserDetailsManager inMemoryUserDetailsManager;

	@Autowired
	AppUserDetailsService appUserDetailsService;

	@GetMapping("")
	public List<MenuItem> getAllMenuItems() {
		logger.debug("Start retrieving menu items");
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String user = authentication.getName();
		UserDetails userDetails = appUserDetailsService.loadUserByUsername(user);
		String role = userDetails.getAuthorities().toArray()[0].toString();

		if (role.contains("ROLE_ADMIN")) {
			return menuItemService.getMenuItemListAdmin();
		} else
			return menuItemService.isActiveSevice();
	}

	@GetMapping("/{id}")
	public MenuItem getMenuItem(@PathVariable int id) {
		logger.debug("Start retrieving menu item from service");
		logger.debug("End retrieving menu items");
		return menuItemService.getMenuItem(id);
	}

	@PutMapping
	public ResponseTransfer maodifyMenuItem(@RequestBody MenuItem menuItem) {
		logger.debug("Start modifying menu items");
		menuItemService.maodifyMenuItem(menuItem);
		logger.debug("End retrieving menu items");

		return new ResponseTransfer("Sucess");
	}

}
