//package com.cognizant.truyum.dao;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//
//import org.springframework.stereotype.Component;
//
//import com.cognizant.truyum.model.Cart;
//import com.cognizant.truyum.model.MenuItem;
//
//@Component
//public class CartDaoCollectionImpl implements CartDao {
//
//	private static HashMap<String, Cart> userCart;
//	// userCart is private static of HashMap type
//
//	public CartDaoCollectionImpl() {
//
//	//	ArrayList<MenuItem> menuItem = new ArrayList<MenuItem>();
//
//		if (userCart == null) {
//			userCart = new HashMap<String, Cart>();
//	//		Cart cart = new Cart(menuItem, menuItem.size());
//		}
//
//	}
//
//	@Override
//	public void addCartItem(String userId, long menuItemId) {
//		// TODO Auto-generated method stub
//
//		MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
//		//MenuItem menuItem = menuItemDao.getMenuItem(menuItemId);
//
//		if (userCart.containsKey(userId)) {
//
//			ArrayList<MenuItem> menuItemList = new ArrayList<MenuItem>();
//			Cart c = (Cart) userCart.get(userId);
//			menuItemList.addAll(c.getMenuItem());
//			menuItemList.add(menuItemDao.getMenuItem(menuItemId));
//		//	c.setMenuItem(menuItemList);
//		} else {
//			ArrayList<MenuItem> menuItemList = new ArrayList<MenuItem>();
//
//			menuItemList.add(menuItemDao.getMenuItem(menuItemId));
//			//Cart c = new Cart(menuItemList, menuItemList.size());
//		//	userCart.put(userId, c);
//
//		}
//
//	}
//
//	@Override
//	public Cart getAllCartItems(String userId) throws CartEmptyException {
//		// TODO Auto-generated method stub
//
//		if (userCart.containsKey(userId)) {
//
//			ArrayList<MenuItem> menuItemList = new ArrayList<MenuItem>();
//			Cart cart = (Cart) userCart.get(userId);
//			menuItemList.addAll(cart.getMenuItem());
//
//			double total = 0;
//			if (!menuItemList.isEmpty()) {
//				for (MenuItem menuItem : menuItemList) {
//			//		total += menuItem.getPrice();
//				}
//				cart.setTotal(total);
//
//				return cart;
//			} else {
//				throw new CartEmptyException();
//
//			}
//
//		}
//
//		return null;
//	}
//
//	@Override
//	public void removeCartItem(String userId, long menuItem) {
//		// TODO Auto-generated method stub
//
//		if (userCart.containsKey(userId)) {
//
//			ArrayList<MenuItem> menuItemList = new ArrayList<MenuItem>();
//			Cart cart = (Cart) userCart.get(userId);
//			menuItemList.addAll(cart.getMenuItem());
//			int i = 0;
////			for (MenuItem menuitem : menuItemList) {
//////			//	if (menuitem.getId() == menuItem) {
//////					break;
//////				}
//////				i++;
//////			}
//
//		//	menuItemList.remove(i);
//		//	cart.setMenuItem(menuItemList);
//		}
//
//	}
//
//}
