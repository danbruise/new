package com.cognizant.truyum.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.cognizant.truyum.model.User;

public interface UserRepository extends JpaRepository<User, Integer> {

	@Query(value = "select u from User u where u.username = :id")
	User findAllById(@Param("id") String userId);

	@Query(value = "select sum(me_price) from menu_item where me_id in(select ct_pr_id from cart where ct_us_id=(select us_id from user where us_name= :name))", nativeQuery = true)
	public double getCartTotal(@Param(value = "name") String name);

	@Query(value = "select u from User u where u.username = :id")
	User findAllByUserName(@Param("id") String username);

}
