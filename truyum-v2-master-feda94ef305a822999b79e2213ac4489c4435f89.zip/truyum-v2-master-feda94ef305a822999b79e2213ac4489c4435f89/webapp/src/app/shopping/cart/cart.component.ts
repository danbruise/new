import { Component, OnInit } from '@angular/core';
import { cart } from '../cart';
import { CartServiceService } from '../cart-service.service';
import { FoodServiceService } from 'src/app/food/food-service.service';
import { AuthServiceService } from 'src/app/site/auth-service.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cart:cart;
uId:string;
msg:string="";
  constructor(private _auth:AuthServiceService, private cartService:CartServiceService,private foodService:FoodServiceService) { }

  ngOnInit() {
    this.uId=this._auth.userName;
    this.cartService.calculateTotal();
    this.cart = this.cartService.getCart(this.uId).subscribe((data)=>{
      //alert("cartcomnent subscribe : ");
      this.cart=data;

    //  alert(JSON.stringify(this.cart));
    },(error : HttpErrorResponse)=>{
      this.msg=error.error.message;
      //this.cart.foodItemList.=error;
     // alert("erro"+error);
      if(error instanceof Error)
      {
        alert("errrrr cllient"+error.message)
      }else
      {
          alert("server side"+error);
      
      }
//alert("get by id"+JSON.stringify(this.cart))
    }
);
  }
  removeFromCart(id){
    this.foodService.removeFromCart(id,this.uId);
    this.ngOnInit();
 
  }

  

}
