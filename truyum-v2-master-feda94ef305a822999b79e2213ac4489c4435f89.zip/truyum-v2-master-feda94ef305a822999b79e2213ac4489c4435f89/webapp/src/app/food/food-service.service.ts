import { Injectable, Output, EventEmitter } from '@angular/core';
import { item } from './item-info/item';
import { Subject} from 'rxjs';
import { CartServiceService } from '../shopping/cart-service.service';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { AuthServiceService } from '../site/auth-service.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})

export class FoodServiceService {

  private subject = new Subject<item[]>();
  isAdmin:boolean = false;
  addedToCart:boolean = false;
  cartAddedId:number;
  isLoggedIn:boolean = false;
  clickedOnAdd:boolean = false;


  items:any;
  constructor(private _httpClient:HttpClient ,private cartService:CartServiceService,private router:Router) { }
 // url : string = "http://localhost:9090/menu-items";
baseUrl:string=environment.baseUrl;

  // getFoodItems(): any {
   
  //   return this._httpClient.get<any>(this.url);
  // }
  
  getAllFoodItems():any {

    if(localStorage.getItem('token')) {
   // alert("in menu initial value of troken  :" + localStorage.getItem('token'));
    var headers=new HttpHeaders();
    headers.set('Content-type','Application/json');
    headers=headers.set("Authorization",'Bearer '+localStorage.getItem('token'));

  //  alert("Token is here "+localStorage.getItem('token'));
    //alert("Header "+ JSON.stringify(headers));

    return  this._httpClient.get<any>(this.baseUrl,{headers});

  //  return this._httpClient.get<any>(this.url);
  }else {
    let username ='default'
    let password='pwd'
    var headers=new HttpHeaders();

     headers=headers.set("Authorization",'Basic '+btoa(username+':'+password));
    return  this._httpClient.get<any>(this.baseUrl,{headers});

  }
}

  getSubject(): Subject<item[]> {
    return this.subject;
  }

  getFoodItem(foodItemId:number):any {

   // alert("get food item")
    var headers=new HttpHeaders();
    headers.set('Content-type','Application/json');
    headers=headers.set("Authorization",'Bearer '+localStorage.getItem('token'));

    //alert("Token is here "+localStorage.getItem('token'));
   // alert("Header "+ JSON.stringify(headers));

    return  this._httpClient.get<any>(this.baseUrl+ "/" + foodItemId,{headers});
    // return this._httpClient.get<any>(this.url + "/" + foodItemId);
  }

  updateFoodItem(foodItem:item){

   // alert("updated")
    var headers=new HttpHeaders();
    headers.set('Content-type','Application/json');
    headers=headers.set("Authorization",'Bearer '+localStorage.getItem('token'));

   // alert("Token is here "+localStorage.getItem('token'));
    //alert("Header "+ JSON.stringify(headers));

    return  this._httpClient.put<any>(this.baseUrl,foodItem,{headers});
    //return this._httpClient.put<any>(this.url ,foodItem);
  }

  addToCart(foodItemId:number,userId) {
    if(this.isLoggedIn){
   //   alert("foodiD ==> "+foodItemId)
    
      this.cartService.addCart(foodItemId,userId).subscribe();
      this.addedToCart = true;
      this.cartAddedId = foodItemId;
    }
    else{

      this.cartService.addCart(foodItemId,userId).subscribe(
        (res)=>{
         // alert("in cart service before login")
        },(error : HttpErrorResponse)=>{
          this.items=error;
          //alert("cart erro"+error);
          if(error instanceof Error)
          {
            alert("cart cust errrrr cllient"+error)
          }else
          {
            alert("cart customer----- server side"+error.message);
          //  alert("cart customer----- server side"+error.statusText);
            
          }
       // alert("get by id"+this.items.json)
        }
      );
      this.addedToCart = false;
      this.cartAddedId = foodItemId;
      this.clickedOnAdd = true;
      this.router.navigate(['login'])
    }
  }
  removeFromCart(foodItemId:number,uId) {
 
   // alert("foodService removemethod : ");
    this.cartService.removeCart(uId,foodItemId).subscribe(
    (res)=>{ 
    // alert("deleted successfully")  
        this.router.navigate(['cart']);
        }

    );

  }
  
  
}
