import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core'; 
import { item } from './item';
import { FoodServiceService } from '../food-service.service';

@Component({
  selector: 'app-item-info',
  templateUrl: './item-info.component.html',
  styleUrls: ['./item-info.component.css']
})
export class ItemInfoComponent implements OnInit {

  @Input() item:item;
  @Output() addToCartClicked = new EventEmitter();
  isAdmin:boolean;
  cartAddedId:number;
  
  constructor(private foodService:FoodServiceService) { }

  ngOnInit() {
    this.isAdmin = this.foodService.isAdmin;
  }
  displayAddToCart(id:number) {
    this.cartAddedId = id;
    //alert("cart added id "+this.cartAddedId)

  }

}
