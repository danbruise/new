import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { item } from '../item-info/item';
import { FoodServiceService } from '../food-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-item-edit',
  templateUrl: './item-edit.component.html',
  styleUrls: ['./item-edit.component.css']
})
export class ItemEditComponent implements OnInit {

  categories = ["Starter","Main Course","Dessert","Drinks"];
  itemForm: FormGroup;
  foodItem:any;
  message : string;
  foodItemId  :any= this.route.snapshot.paramMap.get('id');
  save: boolean=false;
    
  constructor(public datepipe: DatePipe,private formBuild:FormBuilder,private foodservice:FoodServiceService,private route : ActivatedRoute,private router:Router) { }

  ngOnInit() {
    
    
    this.foodservice.getFoodItem(this.foodItemId).subscribe((res)=> {
  //  alert("in edit sub ===")  
      this.foodItem = res;

      let latest_date =this.datepipe.transform(this.foodItem.dateOfLaunch, 'yyyy-MM-dd');


this.itemForm = this.formBuild.group({
itemName: [this.foodItem.name,[
  Validators.required,
  Validators.minLength(2),
  Validators.maxLength(20)
]],
itemURL: [this.foodItem.image,[
  Validators.required
]],
price: [this.foodItem.price,[
  Validators.required
]],
 dateOfLaunch: [latest_date,[
   Validators.required
 ]],
category: [this.foodItem.category,[
  Validators.required
]],
active: [this.foodItem.active,[
  Validators.required
]],
freeDelivery: [this.foodItem.freeDelivery]
})



//      alert("kdjnbgvfdjksngjknvgskjdnsjivkdjdsbngvdjsknvgdjsk" + JSON.stringify(res));
    },
    (error : HttpErrorResponse)=>{
      this.foodItem=error;
      //alert("erro"+error);
      if(error instanceof Error)
      {
        alert("errrrr cllient"+error)
      }else
      {
        alert("server side"+error.message);
      }
   // alert("get by id"+this.foodItem.json)
    }
    );

  //     var d  = new Date(this.foodItem.dateOfLaunch);
  // //    alert(d.toLocaleDateString);

  // //  alert("item-edit onInit food item : " + JSON.stringify(this.foodItem));
  //   this.foodItem.dateOfLaunch.setDate(this.foodItem.dateOfLaunch.getDate()+1);
  //   this.itemForm = this.formBuild.group({
  //     itemName: [this.foodItem.name,[
  //       Validators.required,
  //       Validators.minLength(2),
  //       Validators.maxLength(20)
  //     ]],
  //     itemURL: [this.foodItem.image,[
  //       Validators.required
  //     ]],
  //     price: [this.foodItem.price,[
  //       Validators.required
  //     ]],
  //     dateOfLaunch: [this.foodItem.dateOfLaunch.toISOString().substring(0,10),[
  //       Validators.required
  //     ]],
  //     category: [this.foodItem.category,[
  //       Validators.required
  //     ]],
  //     active: [this.foodItem.active,[
  //       Validators.required
  //     ]],
  //     freeDelivery: [this.foodItem.freeDelivery]
  //   })

  }

  get itemName() {
    return this.itemForm.get('itemName');
  }
  get itemURL() {
    return this.itemForm.get('itemURL');
  }
  get price() {
    return this.itemForm.get('price');
  }
  get dateOfLaunch() {
    return this.itemForm.get('dateOfLaunch');
  }
  get category() {
    return this.itemForm.get('category');
  }
  get active() {
    return this.itemForm.get('active');
  }
  get freeDelivery() {
    return this.itemForm.get('freeDelivery');
  }
  onSubmit() {

    //alert("onsubmit() method called !! fooditem : " + JSON.stringify(this.foodItem));
    this.save=true;
    let newItem:any = {
      id:this.foodItem.id,
      name:this.itemForm.value["itemName"],
      price:+this.itemForm.value["price"],
      active:this.itemForm.value["active"],
    dateOfLaunch:new Date(this.itemForm.value["dateOfLaunch"]),
    category:this.itemForm.value["category"],
    freeDelivery:this.itemForm.value["freeDelivery"],
    image:this.itemForm.value["itemURL"]
  }
    this.foodservice.updateFoodItem(newItem).subscribe((res)=> {
      this.message =res
   
    }
      
      );
  //  this.router.navigate(['search-bar'])
  }

}
