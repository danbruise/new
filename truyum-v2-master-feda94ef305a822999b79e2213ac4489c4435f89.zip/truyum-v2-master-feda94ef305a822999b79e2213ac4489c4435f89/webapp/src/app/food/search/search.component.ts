import { Component, OnInit, Input } from '@angular/core';
import { item } from '../item-info/item';
import { FoodServiceService } from '../food-service.service';
import { AuthServiceService } from 'src/app/site/auth-service.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  searchKey:string;
  itemList:any;
  filteredItemList:any;
  isAdmin:boolean;
isCart:boolean;
  constructor(private foodService:FoodServiceService,private _auth:AuthServiceService) { 
    //localStorage.removeItem('token');
  }

  ngOnInit() {

   
    this.isAdmin = this.foodService.isAdmin;
this.isCart=this._auth.loggedIn;
    if(!this.isAdmin && !this.isCart)
  {
    localStorage.removeItem('token')
  }// alert("SearchComponent onInit() item chi list :" + JSON.stringify(this.itemList));
  this.foodService.getAllFoodItems().subscribe((res)=> this.itemList = res);
  this.filteredItemList = this.itemList;
 
}

  search() {
   // alert("SearchComponent serch function item chi list :" + JSON.stringify(this.itemList));
    this.filteredItemList = this.itemList.filter(item => item.name.toLocaleLowerCase().includes(this.searchKey.toLocaleLowerCase()));
    this.foodService.getSubject().next(this.filteredItemList);
  }
}
