import { Component, OnInit, Input, EventEmitter } from '@angular/core';
import { item } from '../item-info/item';
import { FoodServiceService } from '../food-service.service';
import { CartServiceService } from 'src/app/shopping/cart-service.service';
import { MenuItemService } from 'src/app/service/menu-item.service';
import { HttpErrorResponse } from '@angular/common/http';
import { UserServiceService } from 'src/app/site/user-service.service';
import { AuthServiceService } from 'src/app/site/auth-service.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

   items:any;
   isAdmin:boolean;
  uId:string;
  constructor(private foodService:FoodServiceService, private _auth:AuthServiceService,private cartService:CartServiceService,private userIdservice:UserServiceService,private authServe:AuthServiceService) { 
    
  }

  ngOnInit() {
    this.uId=this._auth.userName;
    this.isAdmin = this.foodService.isAdmin;
    if(this.isAdmin){
      this.foodService.getAllFoodItems().subscribe((res)=>{ this.items = res
       // alert("admin data --"+JSON.stringify(this.items))
      });
      this.foodService.getSubject().subscribe((data) => {
        this.items = data;

        
      });
    }
    else{ 
    //  alert("customer login")
      this.foodService.getAllFoodItems().subscribe((res)=> {
        this.items = res;
       // alert("customer data --"+JSON.stringify(this.items))
      
      },(error : HttpErrorResponse)=>{
        this.items=error;
       // alert("erro"+error);
        if(error instanceof Error)
        {
          alert("cust errrrr cllient"+error)
        }else
        {
          alert("customer----- server side"+error.message);
          alert("customer-----++++++++ server side"+error.statusText);
          
        }
     // alert("get by id"+this.items.json)
      }
      );

      this.foodService.getSubject().subscribe((data) => {
        this.items = data;
      },
      (error : HttpErrorResponse)=>{
        this.items=error;
      //  alert("erro"+error);
        if(error instanceof Error)
        {
          alert("errrrr cllient"+error)
        }else
        {
          alert("server side"+error.message);
        }
    //  alert("get by id"+this.items.json)
      }
      ); 
    //  alert("after ----->");



    }
  
    }
    addToCart(menuItemId)
    {
      //this.userIdservice.getUser(this.authServe.loggedInUser.);
      this.foodService.addToCart(menuItemId,this.uId) ;
    }
    
  }

