import { Injectable } from '@angular/core';
import { UserServiceService } from './user-service.service';
import { Router } from '@angular/router';
import { FoodServiceService } from '../food/food-service.service';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {
  userName:string;
  loggedInUser={loggedOut:true};
  validCredentials:boolean = true;
  accessToken: string; // JWT token
  redirectUrl = '/';
  loggedIn:boolean = false;
  loggedInUserId:string="";
  temp:boolean=false;
 // private authenticationApiUrl = 'http://localhost:9090/authenticate';
  token: string="";
  role:string="";

  authUrl:string = environment.authbaseUrl;


  constructor(private _httpclient:HttpClient,private userService:UserServiceService,public router: Router,private foodService:FoodServiceService) { }


  authenticate(user: string, password: string): Observable<any>
{
  var credentials=btoa(user + ':' + password)
  let headers = new HttpHeaders();
  headers = headers.set('Authorization', 'Basic ' + credentials);
  return this._httpclient.get(this.authUrl, {headers});
}




  authenticateUser(user) {
    // for(let validUser of this.userService.userList){
    //   if(validUser.username == user.username && validUser.password == user.password){

        this.authenticate(user.username,user.password).subscribe(
          (res)=>{
           
            //  alert("Token is : "+res.token);
            
            //  alert("Token is : "+JSON.stringify(res));
            //  alert("role   ====>"+res.role);
              localStorage.setItem ('token', res.token);
              localStorage.setItem ('role', res.role);
              
              //alert("Local Storage madhala token !!! "+localStorage.getItem('token'));
              //alert("Local Storage madhala ROLE !!! "+localStorage.getItem('role'));
               
             // this.setToken(res.token) 
              //this.authenticationServe.setToken(localStorage.getItem('token'));
             // alert("alaaa");
              this.loggedInUser = user;
              this.userName=user.username;
              this.validCredentials = true;
              if(res.role ==='ROLE_ADMIN')
                this.foodService.isAdmin = true;
              this.router.navigate(['search-bar']);
              this.loggedIn = true;
              this.foodService.isLoggedIn = true;
      
              this.loggedInUserId=user.id;
          
          },
          (error : HttpErrorResponse)=>{
            //this.employeeList=error;
            this.validCredentials =false;
            this.router.navigate(['login']);
         //   alert("error in authenticate"+error.message);
            if(error instanceof Error)
            {
              alert("error cllient"+error.message)
            }else
            {
              alert("server side"+error.message);
            }
          }
          
            );
      
    
     
  }
  logout() {
    this.loggedInUser = {loggedOut:true};
    this.foodService.isAdmin = false;
    this.loggedIn = false;
    this.foodService.isLoggedIn = false;
    this.foodService.addedToCart = false;
    //localStorage.setItem('token',"");
   // alert("iam in logout------"+localStorage.getItem('token'))
    localStorage.removeItem('token');
   
  //  alert("iam in logout------"+localStorage.getItem('token'))

    this.router.navigate(['login']);
    // this.router.navigate(['search-bar']);
  }
  setToken(token:string)
  {
    this.token=token;
  }
  getToken()
  {
    return this.token;
  }
  setRole(role:string)
  {
    this.role=role;
  }
  getRole()
  {
    return this.role;
  }
}
