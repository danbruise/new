import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { User } from './user';
import { AuthServiceService } from './auth-service.service';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  userList = [
    {id:"1",username:'admin',firstname:"Deepika",lastname:"Bhat",password:"pwd"},
    {id:"2",username:'user',firstname:"1",lastname:"1",password:"pwd"},
    {id:"3",username:'a',firstname:"b",lastname:"c",password:"a"}
  ];
  
  userName:User;
useradded:boolean;
msg:string=null;
cartUrl:string=environment.cartUrl;
  constructor(private router:Router,private _httpClient:HttpClient) { }



addNewUser(newUser:User):Observable<any>
{
  //alert("I am in http add method")
 ///alert("userrr"+JSON.stringify(newUser))


 // alert("url user"+JSON.stringify(this._httpClient.post(this.cartUrl,newUser)));
  this.msg=null;
  return this._httpClient.post(this.cartUrl,newUser);


}




  addUser(user:any) {
    this.userList.push(user);
//alert("userrr"+JSON.stringify(user))
    this.addNewUser(user).subscribe((res)=>{

        this.useradded=res;
        //alert("user added value ==>"+this.useradded);
        this.router.navigate(['login']);
      
    },
    (error : HttpErrorResponse)=>{
      //this.employeeList=error;
     this.msg=error.message;
     
      //this.router.navigate(['login']);
     // alert("error in authenticate"+error.message);
      if(error instanceof Error)
      {
        alert("error cllient"+error.message)
      }else
      {
        alert("server side"+error.message);
      }
    }
    )


    //this.router.navigate(['login']);
  }
  getUser(username:string){
    let user = this.userList.filter((user)=>(user.username==username));
    return user[0];
  }

  
}