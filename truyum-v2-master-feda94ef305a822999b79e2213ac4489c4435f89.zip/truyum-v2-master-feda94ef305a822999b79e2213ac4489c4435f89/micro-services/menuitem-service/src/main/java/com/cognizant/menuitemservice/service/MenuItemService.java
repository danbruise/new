package com.cognizant.menuitemservice.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.menuitemservice.model.MenuItem;
import com.cognizant.menuitemservice.repository.MenuItemRepository;

@Service
public class MenuItemService {

	@Autowired
	MenuItemRepository menuItemRepository;

	// public List<MenuItem> getMenuItemListCustomer()
	// {
	// return menuItemCollectionImpl.getMenuItemListCustomer();
	// }
	//
	@Transactional
	public MenuItem getMenuItem(Integer menuItemId) {
		// System.err.println(menuItemRepository.getOne(menuItemId).toString());

		return menuItemRepository.getOne(menuItemId); // getOne(menuItemId);
	}

	@Transactional
	public void maodifyMenuItem(MenuItem menuItem) {

		menuItemRepository.save(menuItem);
	}

	// public List<MenuItem> getMenuItemListAdmin()
	// {
	// return menuItemCollectionImpl.getMenuItemListAdmin();
	// }
	@Transactional
	public List<MenuItem> isActiveSevice() {
		return menuItemRepository.isActive();
	}

	@Transactional
	public List<MenuItem> getMenuItemListAdmin() {
		return menuItemRepository.findAll();
	}

}
