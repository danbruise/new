package com.cognizant.menuitemservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.menuitemservice.dto.CartDTO;
import com.cognizant.menuitemservice.exception.CartEmptyException;
import com.cognizant.menuitemservice.service.CartService;


@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/carts")
public class CartDaoController {

	private static final Logger logger = LoggerFactory.getLogger(CartDaoController.class);
	@Autowired
	public CartService cartService;

	@PostMapping("/{userId}/{menuItemId}")

	public ResponseTransfer addCartItem(@PathVariable String userId, @PathVariable int menuItemId) {

		logger.debug("inside controller--------------------------------------");
		cartService.addCartItemService(userId, menuItemId);
		return new ResponseTransfer("Added successfully !!");
	}

	@GetMapping("/{userId}")
	public CartDTO getAllCartItems(@PathVariable String userId) throws CartEmptyException {
	
		try {
			return cartService.getAllCartItems(userId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new CartEmptyException();
		}
	}

	@DeleteMapping("/{userId}/{menuItem}")
	public ResponseTransfer removeCartItem(@PathVariable String userId, @PathVariable long menuItem) {

		cartService.removeCartItem(userId, menuItem);
		return new ResponseTransfer("Item deleted successfully !!");

	}

}
