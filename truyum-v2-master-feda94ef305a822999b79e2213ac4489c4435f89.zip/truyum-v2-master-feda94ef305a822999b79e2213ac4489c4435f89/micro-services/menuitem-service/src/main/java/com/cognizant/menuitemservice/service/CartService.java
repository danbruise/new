package com.cognizant.menuitemservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.menuitemservice.dto.CartDTO;
import com.cognizant.menuitemservice.exception.CartEmptyException;
import com.cognizant.menuitemservice.model.MenuItem;
import com.cognizant.menuitemservice.model.User;
import com.cognizant.menuitemservice.repository.CartRepository;
import com.cognizant.menuitemservice.repository.MenuItemRepository;
import com.cognizant.menuitemservice.repository.UserRepository;




@Service
public class CartService {
	private static final Logger logger = LoggerFactory.getLogger(CartService.class);
	@Autowired
	public CartRepository cartRepository;

	@Autowired
	public UserRepository userRepository;

	@Autowired
	public MenuItemRepository menuItemRepository;

	@Transactional
	public void addCartItemService(String userId, int menuItemId) {
		logger.debug("userID: " + userId + " menuItemId: " + menuItemId);
		User user = userRepository.findAllById(userId);
		Optional<MenuItem> menu = menuItemRepository.findMenuItemRep(menuItemId);
		MenuItem menuItem = menu.get();
		user.getCartList().add(menuItem);
		userRepository.save(user);
		// Logger.debug("Cart List :"+);

		// cartRepository.addCartItem(userId,menuItemId);

	}

	@Transactional
	public CartDTO getAllCartItems(String name) throws CartEmptyException {
		List<MenuItem> menuItemList = menuItemRepository.getMenuItems(name);
		// System.err.println("menuItem
		// List"+menuItemRepository.getMenuItems(name));
		double total = userRepository.getCartTotal(name);
		CartDTO cart = new CartDTO(menuItemList, total);
		return cart;
	}

	// public double getTotal(String name) throws CartEmptyException{
	// return userRepository.getCartTotal(name);
	//
	//
	//// return cartRepository.getAllCartItems(userId);
	//
	// }
	//
	@Transactional
	public void removeCartItem(String userId, long menuItem) {
		// cartRepository.removeCartItem(userId, menuItem);
		// menuItemRepository.getMenuItems(userId);
		User users = userRepository.findAllById(userId);
		List<MenuItem> menuItemList = new ArrayList<MenuItem>();
		menuItemList.addAll(users.getCartList());
		int i = 0;

		for (MenuItem menu : menuItemList) {
			if (menu.getId() == menuItem)
				break;
			i++;
		}

		// System.err.println(menuItemList.get(i));
		menuItemList.remove(i);
		users.setCartList(menuItemList);
		userRepository.save(users);

	}

}
