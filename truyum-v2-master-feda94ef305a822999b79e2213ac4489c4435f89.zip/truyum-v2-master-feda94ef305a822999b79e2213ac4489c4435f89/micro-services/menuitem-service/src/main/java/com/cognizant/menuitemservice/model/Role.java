package com.cognizant.menuitemservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "role")
public class Role {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ro_id")
	private int ro_id;
	@Column(name = "ro_name")
	private String ro_name;

	//// @ManyToMany(fetch=FetchType.EAGER)
	// @JoinTable(name="user_role"
	//// ,joinColumns={@JoinColumn(name="ur_ro_id")},inverseJoinColumns={@JoinColumn(name="ur_us_id")})
	// private List<User> userList;
	//
	// public List<User> getUserList() {
	// return userList;
	// }
	// public void setUserList(List<User> userList) {
	// this.userList = userList;
	// }
	public int getRo_id() {
		return ro_id;
	}

	public void setRo_id(int ro_id) {
		this.ro_id = ro_id;
	}

	public String getRo_name() {
		return ro_name;
	}

	public void setRo_name(String ro_name) {
		this.ro_name = ro_name;
	}

	@Override
	public String toString() {
		return "Role [ro_id=" + ro_id + ", ro_name=" + ro_name + "]";
	}

	public Role(int ro_id, String ro_name) {
		super();
		this.ro_id = ro_id;
		this.ro_name = ro_name;
	}

	public Role() {
		super();
		// TODO Auto-generated constructor stub
	}

}
