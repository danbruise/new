package com.cognizant.menuitemservice.dto;

import java.util.List;

import com.cognizant.menuitemservice.model.MenuItem;

public class CartDTO {

	// private int ct_id;
	private List<MenuItem> menuItem;

	private double total;

	// public int getCt_id() {
	// return ct_id;
	// }
	//
	// public void setCt_id(int ct_id) {
	// this.ct_id = ct_id;
	// }

	public List<MenuItem> getMenuItem() {
		return menuItem;
	}

	public void setMenuItem(List<MenuItem> menuItem) {
		this.menuItem = menuItem;
	}

	public CartDTO() {
		super();
	}

	public CartDTO(List<MenuItem> menuItem, double total) {
		super();
		this.menuItem = menuItem;
		this.total = total;
	}

	@Override
	public String toString() {
		return "Cart [ menuItem=" + menuItem + ", total=" + total + "]";
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

}
