package com.cognizant.menuitemservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cognizant.menuitemservice.model.Cart;



public interface CartRepository extends JpaRepository<Cart, Integer> {

	@Query(value = "insert into cart(ct_us_id, ct_pr_id) values(:userId,:menuItemId)", nativeQuery = true)
	void addCartItem(@Param("userId") String userId, @Param("menuItemId") int menuItemId);

}
