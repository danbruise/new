package com.cognizant.menuitemservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cognizant.menuitemservice.model.MenuItem;



@Repository
public interface MenuItemRepository extends JpaRepository<MenuItem, Integer> {

	@Query(value = "select menu from MenuItem menu where menu.active=true and menu.dateOfLaunch<CURDATE()")
	List<MenuItem> isActive();

	@Query(value = "select menu from MenuItem menu where menu.id = :menuid")
	Optional<MenuItem> findMenuItemRep(@Param("menuid") int menuItemId);

	@Query(value = "select * from menu_item where me_id in(select ct_pr_id from cart where ct_us_id =(select us_id from user where us_name = :name))", nativeQuery = true)
	public List<MenuItem> getMenuItems(@Param(value = "name") String name);

}
