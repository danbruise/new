-- Include table data insertion, updation, deletion and select scripts

use final_check;

-- SQL query to insert into movie items.
-- SQL query to insert into movie items.
insert into movie_item(mo_title,mo_box_office,mo_active,mo_date_of_launch,mo_genre,mo_has_teaser,mo_image)
values('Avatar',2787965087.00, true, '2017-03-15','Science Fiction', true,'https://www.foxmovies.com/s3/56ba791b20287.jpg');


insert into movie_item(mo_title,mo_box_office,mo_active,mo_date_of_launch,mo_genre,mo_has_teaser,mo_image)
values('The Avengers', '1518812988', true,'2017-12-23','Superhero', false,'https://m.media-amazon.com/images/M/MV5BMjMxNjY2MDU1OV5BMl5BanBnXkFtZTgwNzY1MTUwNTM@._V1_.jpg');

insert into movie_item(mo_title,mo_box_office,mo_active,mo_date_of_launch,mo_genre,mo_has_teaser,mo_image)
values('Titanic', 2187463944,true,'2018-08-21', 'Romance',false,'https://images-na.ssl-images-amazon.com/images/I/51cXzScT26L.jpg');


insert into movie_item(mo_title,mo_box_office,mo_active,mo_date_of_launch,mo_genre,mo_has_teaser,mo_image)
values('Jurassic World', 1671713208, false,'2017-07-02','Science Fiction', true,'https://images-na.ssl-images-amazon.com/images/I/71jHmuDFwfL._SY606_.jpg');


insert into movie_item(mo_title,mo_box_office,mo_active,mo_date_of_launch,mo_genre,mo_has_teaser,mo_image)
values('Avengers:End Game', 2750760348, true,'2022-11-02','Superhero', true,'https://m.media-amazon.com/images/M/MV5BMTc5MDE2ODcwNV5BMl5BanBnXkFtZTgwMzI2NzQ2NzM@._V1_.jpg');

alter table movie_item change mo_boxOffice mo_box_office DECIMAL(20,2);
alter table movie_item change mo_hasTeaser mo_has_teaser boolean;
select * from movie_item;
desc movie_item;

-- SQL query to get all movie items
select * from movie_item;







