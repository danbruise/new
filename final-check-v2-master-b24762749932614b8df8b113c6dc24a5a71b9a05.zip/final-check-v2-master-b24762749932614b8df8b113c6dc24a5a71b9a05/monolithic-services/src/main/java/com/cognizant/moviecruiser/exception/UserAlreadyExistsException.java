package com.cognizant.moviecruiser.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cognizant.moviecruiser.MovieCruiserApplication;

@SuppressWarnings("serial")
public class UserAlreadyExistsException extends Exception {
	private static final Logger LOGGER = LoggerFactory.getLogger(MovieCruiserApplication.class);

	public UserAlreadyExistsException() {
		LOGGER.info("User Alresy Exists");
	}
}
