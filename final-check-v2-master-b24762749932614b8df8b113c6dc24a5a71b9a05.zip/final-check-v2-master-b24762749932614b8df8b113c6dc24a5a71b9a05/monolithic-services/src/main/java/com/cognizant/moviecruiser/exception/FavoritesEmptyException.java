package com.cognizant.moviecruiser.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cognizant.moviecruiser.MovieCruiserApplication;

@SuppressWarnings("serial")
public class FavoritesEmptyException extends Exception {

	private static final Logger LOGGER = LoggerFactory.getLogger(MovieCruiserApplication.class);

	public FavoritesEmptyException() {
		LOGGER.info("Favorites is Empty");
	}
}
