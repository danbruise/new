package com.cognizant.moviecruiser;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieCruiserApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(MovieCruiserApplication.class, args);

	}

}
