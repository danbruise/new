package com.cognizant.moviecruiser.dao;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Repository;

import com.cognizant.moviecruiser.MovieCruiserApplication;
import com.cognizant.moviecruiser.model.MovieItem;
import com.cognizant.moviecruiser.util.DateUtil;

@Repository

public class MovieItemDaoCollectionImpl implements MovieItemDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(MovieCruiserApplication.class);
	private static ArrayList<MovieItem> movieItemList;
	private static ApplicationContext applicationContext = new ClassPathXmlApplicationContext("moviecruiser.xml");

	@SuppressWarnings("unchecked")
	public MovieItemDaoCollectionImpl() {
		LOGGER.info("START - Movie Dao Collection Impl");
		movieItemList = (ArrayList<MovieItem>) applicationContext.getBean("movieItemList", "ArrayList.class");
		LOGGER.info("END - Movie Dao Collection Impl");
	}

	@Override
	public ArrayList<MovieItem> getMovieItemListAdmin() {
		// TODO Auto-generated method stub
		LOGGER.info("START - Movie Dao Collection Impl");
		return movieItemList;
	}

	@Override
	public ArrayList<MovieItem> getMovieItemListCustomer() throws ParseException {
		// TODO Auto-generated method stub
		LOGGER.info("START - Movie Dao Collection Impl");
		Date date = Calendar.getInstance().getTime();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		String strdate = dateFormat.format(date);
		Date d = DateUtil.convertToDate(strdate);
		ArrayList<MovieItem> movieList = new ArrayList<MovieItem>();
		for (MovieItem movieItem : movieItemList) {
			if ((movieItem.getDateOfLaunch().equals(d) || movieItem.getDateOfLaunch().before(d))
					&& movieItem.isActive()) {
				movieList.add(movieItem);
			}
		}
		LOGGER.info("END - Movie Dao Collection Impl");
		return movieList;
	}

	@Override
	public void modifyMovieItem(MovieItem movieItem) {
		// TODO Auto-generated method stub
		LOGGER.info("START - Movie Dao Collection Impl");
		int i = 0;
		for (MovieItem movie : movieItemList) {
			if (movie.getId() == movieItem.getId()) {
				break;
			}
			i++;
		}
		movieItemList.set(i, movieItem);
		for (MovieItem movie : movieItemList) {
			LOGGER.info("" + movie);
		}
		LOGGER.info("START - Movie Dao Collection Impl");
	}

	@Override
	public MovieItem getMovieItem(long movieItemId) {
		// TODO Auto-generated method stub
		LOGGER.info("START - Movie Dao Collection Impl");
		for (MovieItem movieItem : movieItemList) {
			if (movieItem.getId() == movieItemId) {
				LOGGER.info("END - Movie Dao Collection Impl");
				return movieItem;
			}
		}
		LOGGER.info("END - Movie Dao Collection Impl");
		return null;

	}

}
