package com.cognizant.moviecruiser.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cognizant.moviecruiser.MovieCruiserApplication;
import com.cognizant.moviecruiser.model.MovieItem;
import com.cognizant.moviecruiser.security.AppUserDetailsService;
import com.cognizant.moviecruiser.service.MovieItemService;

@RestController
@RequestMapping("/movie-items")
public class MovieItemController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MovieCruiserApplication.class);
	@Autowired
	MovieItemService movieItemService;
	@Autowired
	AppUserDetailsService appUserDetailsService;
	
//	@Autowired
//	InMemoryUserDetailsManager inMemoryUserDetailsManager;

	@GetMapping
	public List<MovieItem> getAllMovieItems() throws ParseException {
		LOGGER.info("START - Get All movie items");
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String user = authentication.getName();
		UserDetails userDetails = appUserDetailsService.loadUserByUsername(user);
		String role = userDetails.getAuthorities().toArray()[0].toString();
		LOGGER.info("ROLE - "+role);
		if (role.equals("ROLE_ADMIN")) {
			LOGGER.info("END - Get All movie items");
			return movieItemService.getMovieItemListAdmin();
		} else {
			LOGGER.info("END - Get All movie items");
			return movieItemService.isActiveSevice();
		
		}
	}

	@GetMapping("/{id}")
	public MovieItem getMovieItem(@PathVariable int id) {
		LOGGER.info("START - Get Movie item Controller");
		LOGGER.info("END - Get Movie item Controller");
		return movieItemService.getMovieItem(id);

	}

	@PutMapping
	public void modifyMovieItem(@RequestBody MovieItem movieItem) {
		LOGGER.info("START - Modify Movie");
		LOGGER.info("END - Modify Movie");
		movieItemService.modifyMovieItem(movieItem);
	}
}
