package com.cognizant.moviecruiser.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cognizant.moviecruiser.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
	@Query(value = "select u from User u where u.username = :id")
	User findAllById(@Param("id") String userid);
	
	@Query(value = "select count(mo_id) from movie_item where mo_id in(select f_pr_id from favorites where f_us_id=(select us_id from user where us_name= :name))", nativeQuery = true)
	public double getFavoritesTotal(@Param(value = "name") String name);

	@Query(value = "select u from User u where u.username = :username")
	User findAllByUserName(@Param("username") String username);
}
