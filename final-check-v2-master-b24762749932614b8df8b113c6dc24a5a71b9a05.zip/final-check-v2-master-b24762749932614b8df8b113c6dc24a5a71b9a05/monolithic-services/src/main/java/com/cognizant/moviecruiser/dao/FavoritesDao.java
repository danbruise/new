package com.cognizant.moviecruiser.dao;

import java.text.ParseException;

import com.cognizant.moviecruiser.exception.FavoritesEmptyException;
import com.cognizant.moviecruiser.model.Favorites;

public interface FavoritesDao {
	void addFavoritesItem(String userName, long movieItemId) throws ParseException;

	Favorites getAllFavoritesItems(String userName) throws FavoritesEmptyException;

	void removeFavoritesItem(String userName, long movieItemId);
}
