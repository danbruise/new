package com.cognizant.moviecruiser.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cognizant.moviecruiser.model.MovieItem;

@Repository
public interface MovieItemRepository extends JpaRepository<MovieItem, Integer> {
	@Query(value = "select movie from MovieItem movie where movie.active=true and movie.dateOfLaunch<CURDATE()")
	List<MovieItem> isActive();
	
	@Query(value = "select movie from MovieItem movie where movie.id = :movieid")
	Optional<MovieItem> findMovieItemRep(@Param("movieid") int movieItemId);

	@Query(value = "select * from movie_item where mo_id in(select f_pr_id from favorites where f_us_id =(select us_id from user where us_name = :name))", nativeQuery = true)
	public List<MovieItem> getMovieItems(@Param(value = "name") String name);

}
