package com.cognizant.moviecruiser.controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


import com.cognizant.moviecruiser.MovieCruiserApplication;
import com.cognizant.moviecruiser.ResponseTransfer;
import com.cognizant.moviecruiser.exception.UserAlreadyExistsException;
import com.cognizant.moviecruiser.model.User;
import com.cognizant.moviecruiser.repository.UserRepository;
import com.cognizant.moviecruiser.service.UserDetailsService;

@RestController
@RequestMapping("/users")
public class UserController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MovieCruiserApplication.class);
	
	@Autowired
	UserDetailsService userDetailsService;
	
	@Autowired
	UserRepository userRepository;


	@GetMapping("/{username}")
	public User userDetails(@PathVariable String username)
	{
		LOGGER.debug("Start retrieving user details");
		LOGGER.debug("End retrieving user details");

		return userDetailsService.findByUserName(username);
	}
	
	@PostMapping("")
	public ResponseTransfer signUpController(@RequestBody User user) throws UserAlreadyExistsException
	{
		LOGGER.debug("in signup controller");

		return userDetailsService.signup(user);
	}
}
