package com.cognizant.moviecruiser.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cognizant.moviecruiser.MovieCruiserApplication;
import com.cognizant.moviecruiser.dto.FavoritesDTO;
import com.cognizant.moviecruiser.exception.FavoritesEmptyException;
import com.cognizant.moviecruiser.model.MovieItem;
import com.cognizant.moviecruiser.model.User;
import com.cognizant.moviecruiser.repository.FavoritesRepository;
import com.cognizant.moviecruiser.repository.MovieItemRepository;
import com.cognizant.moviecruiser.repository.UserRepository;



@Service
public class FavoritesService {
	private static final Logger LOGGER = LoggerFactory.getLogger(MovieCruiserApplication.class);
	@Autowired
	FavoritesRepository favoritesRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	MovieItemRepository movieItemRepository;

	@Transactional
	public void addFavoritesItem(String userId, int movieItemId) throws ParseException {
		LOGGER.info("START - Favorites Service");
		LOGGER.debug("ID: " + userId + " movieItemId: " + movieItemId);
		User user = userRepository.findAllById(userId);
		Optional<MovieItem> movie = movieItemRepository.findMovieItemRep(movieItemId);
		MovieItem movieItem = movie.get();
		LOGGER.debug("MovieItem :"+movieItem);
		user.getFavoriteList().add(movieItem);
		LOGGER.debug("user list :"+user.getFavoriteList());
		userRepository.save(user);
		LOGGER.info("END - Favorites Service");
	}

	@Transactional
	public FavoritesDTO getAllFavoritesItems(String userId) throws NullPointerException, FavoritesEmptyException {
		List<MovieItem> movieItemList = movieItemRepository.getMovieItems(userId);
		double total = userRepository.getFavoritesTotal(userId);
		LOGGER.debug("Count :"+total);
		FavoritesDTO favorites = new FavoritesDTO(movieItemList, total);
		return favorites;
		
	}

	@Transactional
	public void deleteFavoritesItem(String userId, int movieItemId) 
	{
			User users = userRepository.findAllById(userId);
			List<MovieItem> movieItemList = new ArrayList<MovieItem>();
			movieItemList.addAll(users.getFavoriteList());
			int i = 0;

			for (MovieItem movie : movieItemList) {
				if (movie.getId() == movieItemId)
					break;
				i++;
			}

			// System.err.println(menuItemList.get(i));
			movieItemList.remove(i);
			users.setFavoriteList(movieItemList);
			userRepository.save(users);

		}
	}

