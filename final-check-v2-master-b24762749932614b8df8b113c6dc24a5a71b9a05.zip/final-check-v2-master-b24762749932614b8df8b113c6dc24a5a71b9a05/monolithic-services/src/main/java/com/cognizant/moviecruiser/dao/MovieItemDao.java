package com.cognizant.moviecruiser.dao;

import java.text.ParseException;
import java.util.ArrayList;

import com.cognizant.moviecruiser.model.MovieItem;

public interface MovieItemDao {
	ArrayList<MovieItem> getMovieItemListAdmin();

	ArrayList<MovieItem> getMovieItemListCustomer() throws ParseException;

	void modifyMovieItem(MovieItem movieItem);

	MovieItem getMovieItem(long movieItemId);

}
