package com.cognizant.moviecruiser.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "movie_item")
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class MovieItem {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "mo_id")
	private int id;

	@Column(name = "mo_title")
	private String title;
	
	@Column(name = "mo_box_office")
	private BigDecimal boxOffice;
	
	@Column(name = "mo_active")
	private boolean active;
	
	@Column(name = "mo_date_of_launch")
	private Date dateOfLaunch;
	
	@Column(name = "mo_genre")
	private String genre;
	
	@Column(name = "mo_has_teaser")
	private boolean hasTeaser;
	
	@Column(name = "mo_image")
	private String imageLink;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public BigDecimal getBoxOffice() {
		return boxOffice;
	}
	public void setBoxOffice(BigDecimal boxOffice) {
		this.boxOffice = boxOffice;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public Date getDateOfLaunch() {
		return dateOfLaunch;
	}
	public void setDateOfLaunch(Date dateOfLaunch) {
		this.dateOfLaunch = dateOfLaunch;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public boolean isHasTeaser() {
		return hasTeaser;
	}
	public void setHasTeaser(boolean hasTeaser) {
		this.hasTeaser = hasTeaser;
	}
	public String getImageLink() {
		return imageLink;
	}
	public void setImageLink(String imageLink) {
		this.imageLink = imageLink;
	}
	@Override
	public String toString() {
		return "MovieItem [id=" + id + ", title=" + title + ", boxOffice=" + boxOffice + ", active=" + active
				+ ", dateOfLaunch=" + dateOfLaunch + ", genre=" + genre + ", hasTeaser=" + hasTeaser + ", imageLink="
				+ imageLink + "]";
	}

	

}
