package com.cognizant.moviecruiser.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="favorites")
public class Favorites {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "f_id")
	private int f_id;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "favorites", joinColumns = { @JoinColumn(name = "f_us_id") }, inverseJoinColumns = {
			@JoinColumn(name = "f_pr_id") })
	private List<MovieItem> movieItemList = new ArrayList<MovieItem>();
	//private double noOfFavorites;

	public List<MovieItem> getMovieItemList() {
		return movieItemList;
	}

	public void setMovieItemList(List<MovieItem> movieItemList) {
		this.movieItemList = movieItemList;
	}
//
//	public double getNoOfFavorites() {
//		return noOfFavorites;
//	}
//
//	public void setTotal(double noOfFavorites) {
//		this.noOfFavorites = noOfFavorites;
//	}

	public Favorites(int f_id, ArrayList<MovieItem> movieItemList) {
		super();
		this.f_id = f_id;
		this.movieItemList = movieItemList;
	}

	
}
