package com.cognizant.moviecruiser.controller;

import java.text.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cognizant.moviecruiser.MovieCruiserApplication;
import com.cognizant.moviecruiser.ResponseTransfer;
import com.cognizant.moviecruiser.dto.FavoritesDTO;
import com.cognizant.moviecruiser.exception.FavoritesEmptyException;
import com.cognizant.moviecruiser.service.FavoritesService;

@RestController
@RequestMapping("/favorites")
public class FavoritesController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MovieCruiserApplication.class);
	@Autowired
	FavoritesService favoritesService;

	@PostMapping("/{userId}/{movieItemId}")
	public ResponseTransfer addFavoritesItem(@PathVariable String userId, @PathVariable int movieItemId)
			throws ParseException {
		LOGGER.info("START - Add Favorites Items");
		favoritesService.addFavoritesItem(userId, movieItemId);
		LOGGER.info("END - Add Favorites Items");
		return new ResponseTransfer("favorite item added successfully");
	}

	@GetMapping("/{userId}")
	public FavoritesDTO getAllFavoritesItems(@PathVariable String userId)
			throws NullPointerException, FavoritesEmptyException {
		LOGGER.info("START - Get all Favorites Items");
		try {
			LOGGER.info("END - Get all Favorites Items");
			return favoritesService.getAllFavoritesItems(userId);
		} catch (Exception e) {
			LOGGER.info("END - Get all Favorites Items");
			throw new FavoritesEmptyException();
		}
	}

	@DeleteMapping("/{userId}/{movieItemId}")
	public ResponseTransfer deleteFavoritesItem(@PathVariable String userId, @PathVariable int movieItemId) {
		LOGGER.info("START - Delete Favorite");
		LOGGER.info(userId + "  " + movieItemId);
		favoritesService.deleteFavoritesItem(userId, movieItemId);
		LOGGER.info("END - Delete Favorite");
		return new ResponseTransfer("deleted successfully");
	}
}
