//package com.cognizant.moviecruiser.dao;
//
//import java.text.ParseException;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.Map;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.stereotype.Repository;
//
//import com.cognizant.moviecruiser.MovieCruiserApplication;
//import com.cognizant.moviecruiser.exception.FavoritesEmptyException;
//import com.cognizant.moviecruiser.model.Favorites;
//import com.cognizant.moviecruiser.model.MovieItem;
//
//@Repository
//public class FavoritesDaoCollectionImpl implements FavoritesDao {
//
//	private static final Logger LOGGER = LoggerFactory.getLogger(MovieCruiserApplication.class);
//	private static Map<String, Favorites> userFavorites = new HashMap<String, Favorites>();
//	ArrayList<MovieItem> movieItemList = new ArrayList<MovieItem>();
//
//	public FavoritesDaoCollectionImpl() throws ParseException {
//
//		if (userFavorites.isEmpty()) {
//			LOGGER.info("START - Favorites Dao Collection Impl");
//			@SuppressWarnings("unused")
//			Favorites favorites = new Favorites(movieItemList, 0);
//			LOGGER.info("START - Favorites Dao Collection Impl");
//		}
//	}
//
//	public void addFavoritesItem(String userName, long movieItemId) throws ParseException {
//		// TODO Auto-generated method stub
//		LOGGER.info("START - Favorites Dao Collection Impl");
//		MovieItemDao movieItemDao = new MovieItemDaoCollectionImpl();
//		MovieItem movieItem = movieItemDao.getMovieItem(movieItemId);
//		if (userFavorites.containsKey(userName)) {
//			Favorites favorites1 = userFavorites.get(userName);
//			movieItemList = favorites1.getMovieItemList();
//			movieItemList.add(movieItem);
//		} else {
//			Favorites favorites1 = new Favorites(new ArrayList<MovieItem>(), 0);
//			movieItemList = favorites1.getMovieItemList();
//			movieItemList.add(movieItem);
//			userFavorites.put(userName, favorites1);
//		}
//		LOGGER.info("START - Favorites Dao Collection Impl");
//	}
//
//	@Override
//	public Favorites getAllFavoritesItems(String userName) throws FavoritesEmptyException, NullPointerException {
//		// TODO Auto-generated method stub
//		LOGGER.info("START - Favorites Dao Collection Impl");
//		Favorites favorites1 = userFavorites.get(userName);
//		ArrayList<MovieItem> movieItemList = favorites1.getMovieItemList();
//		try {
//			if (movieItemList.isEmpty()) {
//				throw new FavoritesEmptyException();
//			} else {
//				float NoOfFavorites = 0;
//				for (MovieItem movie : movieItemList) {
//					NoOfFavorites += movie.getBoxOffice();
//				}
//				Favorites favorites = new Favorites(movieItemList, NoOfFavorites);
//				LOGGER.info("END - Favorites Dao Collection Impl");
//				return favorites;
//			}
//		} catch (Exception e) {
//
//		}
//		LOGGER.info("END - Favorites Dao Collection Impl");
//		return null;
//	}
//
//	@Override
//	public void removeFavoritesItem(String userName, long movieItemId) throws NullPointerException {
//		// TODO Auto-generated method stub
//		LOGGER.info("START - Favorites Dao Collection Impl");
//		Favorites f = userFavorites.get(userName);
//		movieItemList = f.getMovieItemList();
//		for (MovieItem movieItem : movieItemList) {
//			if (movieItem.getId() == movieItemId) {
//				double noOfFavorites = f.getNoOfFavorites() - movieItem.getBoxOffice();
//				f.setTotal(noOfFavorites);
//				movieItemList.remove(movieItem);
//				break;
//			}
//		}
//		LOGGER.info("END - Favorites Dao Collection Impl");
//	}
//}
