package com.cognizant.moviecruiser.service;

import java.util.List;
import javax.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cognizant.moviecruiser.MovieCruiserApplication;
import com.cognizant.moviecruiser.model.MovieItem;
import com.cognizant.moviecruiser.repository.MovieItemRepository;



@Service
public class MovieItemService {
	private static final Logger LOGGER = LoggerFactory.getLogger(MovieCruiserApplication.class);

	@Autowired
	MovieItemRepository movieItemRepository;
	
	@Transactional
	public List<MovieItem> isActiveSevice() {
		LOGGER.debug("In movieitem service");
		return movieItemRepository.isActive();
	}
	
	@Transactional
	public List<MovieItem> getMovieItemListAdmin() {
		return movieItemRepository.findAll();
	}

//	public ArrayList<MovieItem> getMovieItemListCustomer() throws ParseException {
//		LOGGER.info("START - Movie Service");
//		return movieItemDao.getMovieItemListCustomer();
//	}
//
//	public ArrayList<MovieItem> getMovieItemListAdmin() {
//		LOGGER.info("START - Movie Service");
//		return movieItemDao.getMovieItemListAdmin();
//	}
//
	public MovieItem getMovieItem(int id) {
		LOGGER.info("START - Movie Service");
		return movieItemRepository.getOne(id);
	}

	public void modifyMovieItem(MovieItem movieItem) {
		LOGGER.info("START - Movie Service");
		movieItemRepository.save(movieItem);
		LOGGER.info("END - Movie Service");
	}
}
