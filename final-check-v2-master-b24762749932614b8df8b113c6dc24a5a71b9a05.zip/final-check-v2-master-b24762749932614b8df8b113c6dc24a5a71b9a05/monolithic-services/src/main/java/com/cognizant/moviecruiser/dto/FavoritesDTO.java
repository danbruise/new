package com.cognizant.moviecruiser.dto;

import java.util.List;
import com.cognizant.moviecruiser.model.MovieItem;

public class FavoritesDTO {

	// private int ct_id;
	private List<MovieItem> MovieItem;

	private double noOfFavorites;

	public double getNoOfFavorites() {
		return noOfFavorites;
	}

	public void setTotal(double noOfFavorites) {
		this.noOfFavorites = noOfFavorites;
	}

	public List<MovieItem> getMovieItem() {
		return MovieItem;
	}

	

	public FavoritesDTO(List<MovieItem> movieItem, double noOfFavorites) {
		super();
		MovieItem = movieItem;
		this.noOfFavorites = noOfFavorites;
	}

	@Override
	public String toString() {
		return "FavoritesDTO [MovieItem=" + MovieItem + ", noOfFavorites=" + noOfFavorites + "]";
	}

	public void setMovieItem(List<MovieItem> MovieItem) {
		this.MovieItem = MovieItem;
	}

	public FavoritesDTO() {
		super();
	}

}
