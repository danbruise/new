package com.cognizant.moviecruiser.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cognizant.moviecruiser.model.Favorites;

@Repository
public interface FavoritesRepository extends JpaRepository<Favorites, Integer>{

	@Query(value = "insert into favorites(f_us_id, f_pr_id) values(:userId,:movieItemId)", nativeQuery = true)
	void addFavoritesItem(@Param("userId") String userId, @Param("movieItemId") int movieItemId);
	
}
