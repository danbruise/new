package com.cognizant.movieservice.controller;

import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.movieservice.ResponseTransfer;
import com.cognizant.movieservice.model.Movie;
import com.cognizant.movieservice.security.AppUserDetailsService;
import com.cognizant.movieservice.service.MovieService;



@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/movie-items")
public class MovieDaoController {

	private static final Logger logger = LoggerFactory.getLogger(MovieDaoController.class);
	@Autowired
	private AppUserDetailsService appUserDetailsService;

	@Autowired
	private MovieService movieService;

	@GetMapping("")
	public List<Movie> getAllMenuItems() {
		logger.debug("in get Movie List");
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String user = authentication.getName();
		UserDetails userDetails = appUserDetailsService.loadUserByUsername(user);
		String role = userDetails.getAuthorities().toArray()[0].toString();

		if (role.contains("ROLE_ADMIN")) {
			return movieService.getMovieAdmin();
		} else
			return movieService.getMovieCustomer();
	}

	@GetMapping("/{id}")
	public Movie getMovie(@PathVariable int id) {
		logger.debug("in get Movie List by id");
		return movieService.getMovie(id);
	}

	@PutMapping
	public ResponseTransfer maodifyMenuItem(@RequestBody Movie menuItem) {
		logger.debug("in update Movie List");
		movieService.maodifyMovieItem(menuItem);
		return new ResponseTransfer("Sucess");
	}

}
