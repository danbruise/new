package com.cognizant.movieservice.repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cognizant.movieservice.model.Users;





public interface UserRepository extends JpaRepository<Users, Integer> {
	@Query(value="select * from user where us_name = :val",nativeQuery=true)
	public Users findByName(@Param (value = "val")String us_name );
	
	@Query(value="select * from user where us_name = :val",nativeQuery=true)
	public Optional<Users> findByName1(@Param (value = "val")String us_name );
	
	@Query(value="select count(me_title) from favorite join movie_list on me_id=fv_pr_id  where fv_us_id in (SELECT us_id from user where us_name = :name);",nativeQuery = true)
	public Optional<Double> getCount(@Param (value="name") String name);
	
}
