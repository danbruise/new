package com.cognizant.movieservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.movieservice.dto.FavoriteDTO;
import com.cognizant.movieservice.exception.FavoritesEmptyException;
import com.cognizant.movieservice.model.Movie;
import com.cognizant.movieservice.model.Users;
import com.cognizant.movieservice.repository.MovieRepository;
import com.cognizant.movieservice.repository.UserRepository;



@Service
public class FavoritesService {

	@Autowired
	public UserRepository userRepository;

	@Autowired
	public MovieRepository movieRepository;

	public void addFavorite(String userId, int movieId) {
		Users users = userRepository.findByName(userId);
		Movie movie = movieRepository.findById(movieId).get();
		users.getMovies().add(movie);
		userRepository.save(users);

	}

	public FavoriteDTO getAllFavorites(String userId) throws FavoritesEmptyException {

		List<Movie> items = movieRepository.getAllFavoriteItems(userId);
		Optional<Double> total = userRepository.getCount(userId);

		FavoriteDTO favoriteDTO = new FavoriteDTO(items, total.get());
		return favoriteDTO;

	}

	public void removeFavorite(String userId, int movieId) {

		Users users = userRepository.findByName(userId);

		ArrayList<Movie> movies = new ArrayList<Movie>();

		movies.addAll(users.getMovies());
		int i = 0;
		for (Movie movie : movies) {
			if (movie.getId() == movieId) {
				break;
			}
			i++;
		}
		movies.remove(i);
		users.setMovies(movies);
		userRepository.save(users);
	}

}