package com.cognizant.movieservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cognizant.movieservice.model.Movie;



@Repository
public interface MovieRepository extends JpaRepository<Movie, Integer> {

	@Query(value = "SELECT * from movie_list where  me_date_of_launch<= curdate() AND  me_active='Yes'", nativeQuery = true)
	List<Movie> getMovieListCustomer();

	@Query(value = "select me_id,me_title,me_gross,me_active, me_date_of_launch, me_genre, me_has_teaser,me_image from favorite join movie_list on me_id=fv_pr_id where fv_us_id in (SELECT us_id from user where us_name = :name)", nativeQuery = true)
	public List<Movie> getAllFavoriteItems(@Param(value = "name") String name);

	@Query(value = "SELECT * from movie_list ", nativeQuery = true)
	List<Movie> getMovieListAdmin();

}
