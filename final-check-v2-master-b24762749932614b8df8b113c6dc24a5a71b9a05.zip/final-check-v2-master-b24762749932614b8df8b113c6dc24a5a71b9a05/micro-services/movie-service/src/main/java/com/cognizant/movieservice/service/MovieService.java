package com.cognizant.movieservice.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.movieservice.model.Movie;
import com.cognizant.movieservice.repository.MovieRepository;




@Service
public class MovieService {

	@Autowired
	private MovieRepository movieRepository;
	@Transactional
	public 	List<Movie> getMovieCustomer()
	{
		return movieRepository.getMovieListCustomer();								
	}
	@Transactional
	public Movie getMovie(int movieId) {
		return movieRepository.findById(movieId).get(); 
	}
	@Transactional
	public void maodifyMovieItem(Movie movieItem){
		movieRepository.save(movieItem);
	}
	@Transactional
	public List<Movie> getMovieAdmin()
	{
		return movieRepository.findAll();
	}
	
}

