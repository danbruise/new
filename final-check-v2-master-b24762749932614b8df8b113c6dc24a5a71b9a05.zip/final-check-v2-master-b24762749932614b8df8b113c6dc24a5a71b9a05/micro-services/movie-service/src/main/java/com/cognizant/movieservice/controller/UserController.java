package com.cognizant.movieservice.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.movieservice.exception.UserAlreadyExistsException;
import com.cognizant.movieservice.model.Users;
import com.cognizant.movieservice.service.UserDetailsService;



@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/users")
public class UserController {
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	UserDetailsService userDetailsService;

	@PostMapping("")
	public boolean signup(@RequestBody @Valid Users user) throws UserAlreadyExistsException {
		logger.debug("User Details !!!!!" + user.toString());
		return userDetailsService.signup(user);

	}
}
