// DateUtil class is for fetching the date in proper format
package com.cognizant.movieservice.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {

	public static Date convertToDate(String date) {

		String pattern = "dd/MM/yyyy";
		SimpleDateFormat simpedateformateobj = new SimpleDateFormat(pattern);

		Date date1 = null;

		try {
			date1 = (Date) (simpedateformateobj.parse(date));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date1;
	}

}
