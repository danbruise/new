package com.cognizant.movieservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.cognizant.movieservice.exception.UserAlreadyExistsException;
import com.cognizant.movieservice.model.Role;
import com.cognizant.movieservice.model.Users;
import com.cognizant.movieservice.repository.UserRepository;


@Service
public class UserDetailsService {
	
	
	@Autowired
	UserRepository userRepository;
	public boolean signup(Users user) throws UserAlreadyExistsException{
		Optional<Users> users = userRepository.findByName1(user.getUsername());
		if(users.isPresent()){
			throw new UserAlreadyExistsException();
		}
		else{
			 BCryptPasswordEncoder bCryptPasswordEncoder= new BCryptPasswordEncoder();
			 user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
			 List<Role> roles = new ArrayList<>();
			 roles.add(new Role(2, "ROLE_USER"));
			 System.err.println("user role list :" + roles);
			 Users user1 = new Users(0,user.getUsername(), user.getPassword(),roles);
			 //user.setRolelist(roles);
			userRepository.save(user1);
			return true;
		}
	
	}
}
