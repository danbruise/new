package com.cognizant.movieservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.movieservice.ResponseTransfer;
import com.cognizant.movieservice.dto.FavoriteDTO;
import com.cognizant.movieservice.exception.FavoritesEmptyException;
import com.cognizant.movieservice.service.FavoritesService;


@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/favorites")
public class FavoritesDaoController {

	@Autowired
	public FavoritesService favoritesService;

	@PostMapping("/{userId}/{movieId}")

	public ResponseTransfer addFavorite(@PathVariable String userId, @PathVariable int movieId) {

		favoritesService.addFavorite(userId, movieId);
		return new ResponseTransfer("Added successfully !!");
	}

	@GetMapping("/{userId}")
	public FavoriteDTO getAllFavorites(@PathVariable String userId) throws FavoritesEmptyException {
		try {
			return favoritesService.getAllFavorites(userId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new FavoritesEmptyException();
		}
	}

	@DeleteMapping("/{userId}/{movieId}")
	public ResponseTransfer removeFavorite(@PathVariable String userId, @PathVariable int movieId) {
		favoritesService.removeFavorite(userId, movieId);
		return new ResponseTransfer("Item deleted successfully !!");

	}

}
