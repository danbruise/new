package com.cognizant.movieservice.dto;

import java.util.List;

import com.cognizant.movieservice.model.Movie;



public class FavoriteDTO {

	public FavoriteDTO(List<Movie> menuItem, double total) {
		super();
		this.menuItem = menuItem;
		this.total = total;
	}

	private List<Movie> menuItem;
	private double total;

	public List<Movie> getMenuItem() {
		return menuItem;
	}

	public void setMenuItem(List<Movie> menuItem) {
		this.menuItem = menuItem;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

}
