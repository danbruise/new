package com.cognizant.movieservice.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cognizant.movieservice.model.Users;
import com.cognizant.movieservice.repository.UserRepository;



@Service
public class AppUserDetailsService implements UserDetailsService {

	@Override
	public String toString() {
		return "AppUserDetailsService [userRepository=" + userRepository + "]";
	}

	@Autowired
	UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String us_name) throws UsernameNotFoundException {

		try {
			Users users = userRepository.findByName(us_name);
			AppUser appUser = new AppUser(users);
			return appUser;
		} catch (Exception e) {
		}
		return null;
	}

}
