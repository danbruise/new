//customized exception class 
package com.cognizant.movieservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="FavoriteDTO is Empty")
public class FavoritesEmptyException extends Exception {

	private static final long serialVersionUID = 1L;

	public FavoritesEmptyException() {
		System.out.println("Cart is Empty !!");

	}
}
