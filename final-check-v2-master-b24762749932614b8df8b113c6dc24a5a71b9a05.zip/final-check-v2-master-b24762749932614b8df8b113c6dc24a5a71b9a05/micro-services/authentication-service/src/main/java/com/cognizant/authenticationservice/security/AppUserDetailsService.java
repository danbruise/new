package com.cognizant.authenticationservice.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cognizant.authenticationservice.model.Users;
import com.cognizant.authenticationservice.repository.UserRepository;



@Service
public class AppUserDetailsService implements UserDetailsService {

	@Override
	public String toString() {
		return "AppUserDetailsService [userRepository=" + userRepository + "]";
	}

	@Autowired
	UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String us_name) throws UsernameNotFoundException {
		try {
			
			Users users = userRepository.findByName(us_name);
			System.err.println("adasad "+users.toString());
			AppUser appUser = new AppUser(users);
			System.err.println("app user" + appUser);
			return appUser;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

}
