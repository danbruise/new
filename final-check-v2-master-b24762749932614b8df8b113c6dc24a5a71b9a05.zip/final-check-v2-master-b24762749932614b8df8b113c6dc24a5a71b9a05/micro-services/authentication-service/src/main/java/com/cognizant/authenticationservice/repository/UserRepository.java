package com.cognizant.authenticationservice.repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cognizant.authenticationservice.model.Users;



public interface UserRepository extends JpaRepository<Users, Integer> {
	@Query(value="select * from user where us_name = :val",nativeQuery=true)
	public Users findByName(@Param (value = "val")String us_name );
	
	@Query(value="select * from user where us_name = :val",nativeQuery=true)
	public Optional<Users> findByName1(@Param (value = "val")String us_name );
	
	@Query(value="select sum(me_price) from cart join menu_item on me_id=ct_pr_id  where ct_us_id in (SELECT us_id from user where us_name = :name);",nativeQuery = true)
	public Optional<Double> getTotal(@Param (value="name") String name);
	

	
//	@Query(value="SELECT new CartDTO (u.menuItem, u.total) from MenuItem u where me_id in  (SELECT ct_pr_id from cart where ct_us_id=2)",nativeQuery = true)
//	public CartDTO getAllCartItems();

}
