import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

 import { FormsModule, ReactiveFormsModule } from '@angular/forms';


import { RouterModule, Routes } from '@angular/router';
import { SignupComponent } from './site/signup/signup.component';
import { LoginComponent } from './site/login/login.component';
import { AuthGaurdService } from './auth-gaurd-service.service';
import { HttpClientModule } from '@angular/common/http';
import { DatePipe } from '@angular/common';

import { MovieEditComponent } from './movie/movie-edit/movie-edit.component';
import { SearchComponent } from './movie/search/search.component';
import { MovieInfoComponent } from './movie/movie-info/movie-info.component';
import { MovieComponent } from './movie/movies/movies.component';
import { FavoriteComponent } from './booking/favorite/favorite.component';




const appRoutes: Routes = [ 
  { path: 'edit-food-item/:id', component: MovieEditComponent, canActivate: [AuthGaurdService]},
  { path: 'signup', component: SignupComponent},
  { path: 'cart', component: FavoriteComponent, canActivate: [AuthGaurdService]},
  { path: 'login',component: LoginComponent},
  { path: 'search-bar',component: SearchComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    MovieInfoComponent,
     MovieComponent,
     SearchComponent,
     FavoriteComponent,
     MovieEditComponent,
     SignupComponent,
     LoginComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: true }
    ),
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule 
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
