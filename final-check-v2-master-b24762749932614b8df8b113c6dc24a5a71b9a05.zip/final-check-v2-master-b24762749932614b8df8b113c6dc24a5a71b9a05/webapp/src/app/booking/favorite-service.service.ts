import { Injectable, Output, EventEmitter } from '@angular/core';
import { cart } from './cart';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CartServiceService {

  @Output() cartUpdated = new EventEmitter();

  private subject = new Subject<any>();
  cartItems:cart =  {foodItemList:[],total:0};
  
cartSUrl:string=environment.cartSUrl;

  constructor(private _httpClient:HttpClient) { }

  getCart(userId):any {

    
    
    var headers=new HttpHeaders();
    headers.set('Content-type','Application/json');
    headers=headers.set("Authorization",'Bearer '+localStorage.getItem('token'));

    return  this._httpClient.get<any>(this.cartSUrl+userId,{headers});
    
  }
  getSubject(): Subject<any> {
    return this.subject;
  }
  calculateTotal() {
    this.cartItems.total = 0;
    for(let i=0;i<this.cartItems.foodItemList.length;i++){
        this.cartItems.total += this.cartItems.foodItemList[i].price;
    }
    this.cartUpdated.emit;
  }
  addCart(foodItemId,userId){

   
    var headers=new HttpHeaders();
    headers.set('Content-type','Application/json');
    headers=headers.set("Authorization",'Bearer '+localStorage.getItem('token'));
    return this._httpClient.post(this.cartSUrl+userId+"/"+foodItemId,"",{headers});
  }

  removeCart(userId,foodItemId){

    var headers=new HttpHeaders();
    headers.set('Content-type','Application/json');
    headers=headers.set("Authorization",'Bearer '+localStorage.getItem('token'));
    return this._httpClient.delete(this.cartSUrl+userId+"/"+foodItemId,{headers});
    }
}
