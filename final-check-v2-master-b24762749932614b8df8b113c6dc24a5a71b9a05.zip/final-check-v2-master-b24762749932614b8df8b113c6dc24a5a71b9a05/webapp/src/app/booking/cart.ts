import { item } from "../movie/movie-info/item";


export interface cart {
    foodItemList:item[];
    total:number;
}