import { Component, OnInit } from '@angular/core';
import { cart } from '../cart';
import { CartServiceService } from '../favorite-service.service';

import { AuthServiceService } from 'src/app/site/auth-service.service';
import { HttpErrorResponse } from '@angular/common/http';
import { MovieServiceService } from 'src/app/movie/movie-service.service';

@Component({
  selector: 'app-cart',
  templateUrl: './favorite.component.html',
  styleUrls: ['./favorite.component.css']
})
export class FavoriteComponent implements OnInit {

  cart:cart;
uId:string;
msg:string="";
  constructor(private _auth:AuthServiceService, private cartService:CartServiceService,private foodService:MovieServiceService) { }

  ngOnInit() {
    this.uId=this._auth.userName;
    this.cartService.calculateTotal();
    this.cart = this.cartService.getCart(this.uId).subscribe((data)=>{
     
      this.cart=data;

      
    },(error : HttpErrorResponse)=>{
      this.msg=error.error.message;
    
    
      if(error instanceof Error)
      {
        console.log("errrrr cllient"+error.message)
      }else
      {
        console.log("server side"+error);
      
      }
    }
);
  }
  removeFromCart(id){
    this.foodService.removeFromCart(id,this.uId);
    this.ngOnInit();
 
  }

  

}
