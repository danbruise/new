import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { User } from './user';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  userList = [
    { id: "1", username: 'admin', firstname: "Shivam", lastname: "Wankhade", password: "pwd" },
    { id: "2", username: 'user', firstname: "1", lastname: "1", password: "pwd" },
    { id: "3", username: 'a', firstname: "b", lastname: "c", password: "a" }
  ];

  userName: User;
  useradded: boolean;
  msg: string = null;
  userUrl: string = environment.userUrl;
  constructor(private router: Router, private _httpClient: HttpClient) { }
  addNewUser(newUser: User): Observable<any> {
    this.msg = null;
    return this._httpClient.post(this.userUrl, newUser);
  }
  addUser(user: any) {
    this.userList.push(user);
    this.addNewUser(user).subscribe((res) => {

      this.useradded = res;

      this.router.navigate(['login']);

    },
      (error: HttpErrorResponse) => {

        this.msg = error.message;


        if (error instanceof Error) {
          console.log("error cllient" + error.message)
        } else {
          console.log("server side" + error.message);
        }
      }
    )
  }
  getUser(username: string) {
    let user = this.userList.filter((user) => (user.username == username));
    return user[0];
  }


}