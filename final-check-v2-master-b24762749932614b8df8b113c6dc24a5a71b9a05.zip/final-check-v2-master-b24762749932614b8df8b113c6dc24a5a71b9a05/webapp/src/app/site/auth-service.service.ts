import { Injectable } from '@angular/core';
import { UserServiceService } from './user-service.service';
import { Router } from '@angular/router';

import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';

import { MovieServiceService } from '../movie/movie-service.service';
import { CartServiceService } from '../booking/favorite-service.service';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {

  loggedInUser = { loggedOut: true };
  validCredentials: boolean = true;
  accessToken: string; // JWT token
  redirectUrl = '/';
  loggedIn: boolean = false;
  loggedInUserId: string = "";
  temp: boolean = false;

  token: string = "";
  role: string = "";
  userName: string;

  authUrl: string = environment.authbaseUrl;


  constructor(private _cartService: CartServiceService, private _httpclient: HttpClient, private userService: UserServiceService, public router: Router, private foodService: MovieServiceService) { }


  authenticate(user: string, password: string): Observable<any> {
    var credentials = btoa(user + ':' + password)
    let headers = new HttpHeaders();
    headers = headers.set('Authorization', 'Basic ' + credentials);
    return this._httpclient.get(this.authUrl, { headers });
  }
  authenticateUser(user) {
    this.authenticate(user.username, user.password).subscribe(
      (res) => {
        localStorage.setItem('token', res.token);
        localStorage.setItem('role', res.role);

        this.loggedInUser = user;
        this.userName = user.username;
        this.validCredentials = true;
        if (res.role === 'ROLE_ADMIN')
          this.foodService.isAdmin = true;
        this.router.navigate(['search-bar']);
        this.loggedIn = true;
        this.foodService.isLoggedIn = true;

        this.loggedInUserId = user.id;

        if (this.foodService.addedToCart) {

          this._cartService.addCart(this.foodService.cartAddedId, this.loggedInUserId).subscribe();
          this.foodService.addedToCart = false;
        }


      },
      (error: HttpErrorResponse) => {

        this.validCredentials = false;
        this.router.navigate(['login']);

        if (error instanceof Error) {
          console.log("error cllient" + error.message)
        } else {
          console.log("server side" + error.message);
        }
      }
    );
  }
  logout() {
    this.loggedInUser = { loggedOut: true };
    this.foodService.isAdmin = false;
    this.loggedIn = false;
    this.foodService.isLoggedIn = false;
    localStorage.removeItem('token');
    this.router.navigate(['login']);
  }
  setToken(token: string) {
    this.token = token;
  }
  getToken() {
    return this.token;
  }
  setRole(role: string) {
    this.role = role;
  }
  getRole() {
    return this.role;
  }
}
