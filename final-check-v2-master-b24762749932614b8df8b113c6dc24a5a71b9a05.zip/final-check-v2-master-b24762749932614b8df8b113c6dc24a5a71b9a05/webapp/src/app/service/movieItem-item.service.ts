import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import {  Subject } from 'rxjs';
import { item } from '../movie/movie-info/item';



@Injectable({
  providedIn: 'root'
})
export class MenuItemService {

  private subject = new Subject<item[]>();
  constructor(private _httpClient:HttpClient) { }
  
  url : string = "http://localhost:9090/menu-items";

  getAllMenuItems():any{
    return this._httpClient.get<any>(this.url);
  }

  getMenuItemsAdmin():any{
    return this._httpClient.get<any>(this.url + "/admin");
  }

}
