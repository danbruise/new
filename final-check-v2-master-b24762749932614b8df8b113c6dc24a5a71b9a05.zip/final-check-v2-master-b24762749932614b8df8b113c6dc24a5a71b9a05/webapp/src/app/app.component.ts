import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from './site/auth-service.service';
import { Router } from '@angular/router';
import { UserServiceService } from './site/user-service.service';
import { MovieServiceService } from './movie/movie-service.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit  {
  
  ngOnInit(): void {
    this.loggedIn();
    this.router.navigate(['search-bar']);
  }
  constructor(private authService:AuthServiceService,public router: Router,private foodService:MovieServiceService) {  
  }
  title = 'truYum';
  isLoggedIn:boolean = false;
  

  loggedIn():boolean {
    if(!this.authService.loggedInUser.loggedOut){
      this.isLoggedIn = true;
      return true
    }
    else{
      this.isLoggedIn = false;
      //alert("iam in logout------"+localStorage.getItem('token'))
      
      //alert("iam in logout------"+localStorage.getItem('token'))
      return false;
    }
  }
  clickOnAddCart(){
    this.foodService.clickedOnAdd = false;
    this.foodService.addedToCart = false;
  }
}
