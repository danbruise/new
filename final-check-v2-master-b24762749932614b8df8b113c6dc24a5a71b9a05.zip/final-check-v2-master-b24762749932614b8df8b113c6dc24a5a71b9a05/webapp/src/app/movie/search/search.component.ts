import { Component, OnInit, Input } from '@angular/core';

import { MovieServiceService } from '../movie-service.service';
import { AuthServiceService } from 'src/app/site/auth-service.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  searchKey: string;
  itemList: any;
  filteredItemList: any;
  isAdmin: boolean;
  isCart: boolean;
  constructor(private foodService: MovieServiceService, private _auth: AuthServiceService) {
  }

  ngOnInit() {


    this.isAdmin = this.foodService.isAdmin;
    this.isCart = this._auth.loggedIn;
    if (!this.isAdmin && !this.isCart) {
      localStorage.removeItem('token')
    }
    this.foodService.getAllFoodItems().subscribe((res) => this.itemList = res);
    this.filteredItemList = this.itemList;

  }

  search() {
    this.filteredItemList = this.itemList.filter(item => item.name.toLocaleLowerCase().includes(this.searchKey.toLocaleLowerCase()));
    this.foodService.getSubject().next(this.filteredItemList);
  }
}
