import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core'; 
import { item } from './item';
import { MovieServiceService } from '../movie-service.service';

@Component({
  selector: 'app-item-info',
  templateUrl: './movie-info.component.html',
  styleUrls: ['./movie-info.component.css']
})
export class MovieInfoComponent implements OnInit {

  @Input() item:item;
  @Output() addToCartClicked = new EventEmitter();
  isAdmin:boolean;
  cartAddedId:number;
  
  constructor(private foodService:MovieServiceService) { }

  ngOnInit() {
    this.isAdmin = this.foodService.isAdmin;
  }
  displayAddToCart(id:number) {
    this.cartAddedId = id;
  }

}
