import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { MovieServiceService } from '../movie-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-item-edit',
  templateUrl: './movie-edit.component.html',
  styleUrls: ['./movie-edit.component.css']
})
export class MovieEditComponent implements OnInit {

  categories = ["Science Fiction", "Superhero", "Romance", "Thriller"];
  itemForm: FormGroup;
  foodItem: any;
  message: string;
  foodItemId: any = this.route.snapshot.paramMap.get('id');
  save: boolean = false;

  activeBoo: boolean;
  teaser: boolean;

  constructor(public datepipe: DatePipe, private formBuild: FormBuilder, private foodservice: MovieServiceService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {


    this.foodservice.getFoodItem(this.foodItemId).subscribe((res) => {
      this.foodItem = res;
      let latest_date = this.datepipe.transform(this.foodItem.dateOfLaunch, 'yyyy-MM-dd');
      if (this.foodItem.active == 'Yes')
        this.activeBoo = true;
      else
        this.activeBoo = false;
      if (this.foodItem.freeDelivery == 'Yes')
        this.teaser = true;
      else
        this.teaser = false;

      this.itemForm = this.formBuild.group({
        itemName: [this.foodItem.name, [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(20)
        ]],
        itemURL: [this.foodItem.image, [
          Validators.required
        ]],
        price: [this.foodItem.price, [
          Validators.required
        ]],
        dateOfLaunch: [latest_date, [
          Validators.required
        ]],
        category: [this.foodItem.category, [
          Validators.required
        ]],
        active: [this.activeBoo, [
          Validators.required
        ]],
        freeDelivery: [this.teaser]
      })
    },
      (error: HttpErrorResponse) => {
        this.foodItem = error;
        console.log("erro" + error);
        if (error instanceof Error) {
          console.log("errrrr cllient" + error)
        } else {
          console.log("server side" + error.message);
        }
        console.log("get by id" + this.foodItem.json)
      }
    );
  }

  get itemName() {
    return this.itemForm.get('itemName');
  }
  get itemURL() {
    return this.itemForm.get('itemURL');
  }
  get price() {
    return this.itemForm.get('price');
  }
  get dateOfLaunch() {
    return this.itemForm.get('dateOfLaunch');
  }
  get category() {
    return this.itemForm.get('category');
  }
  get active() {
    return this.itemForm.get('active');
  }
  get freeDelivery() {
    return this.itemForm.get('freeDelivery');
  }
  onSubmit() {
    this.save = true;
    let newItem: any = {
      id: this.foodItem.id,
      name: this.itemForm.value["itemName"],
      price: +this.itemForm.value["price"],

      active: this.itemForm.value["active"] == true ? "Yes" : "No",
      dateOfLaunch: new Date(this.itemForm.value["dateOfLaunch"]),
      category: this.itemForm.value["category"],
      freeDelivery: this.itemForm.value["freeDelivery"] == true ? "Yes" : "No",
      image: this.itemForm.value["itemURL"]
    }
    this.foodservice.updateFoodItem(newItem).subscribe((res) => {
      this.message = res
    }
    );
  }
}
