import { Component, OnInit, Input, EventEmitter } from '@angular/core';

import { MovieServiceService } from '../movie-service.service';


import { HttpErrorResponse } from '@angular/common/http';
import { UserServiceService } from 'src/app/site/user-service.service';
import { AuthServiceService } from 'src/app/site/auth-service.service';
import { CartServiceService } from 'src/app/booking/favorite-service.service';

@Component({
  selector: 'app-menu',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MovieComponent implements OnInit {

  items: any;
  isAdmin: boolean;
  uId: string;
  constructor(private foodService: MovieServiceService, private _auth: AuthServiceService, private cartService: CartServiceService, private userIdservice: UserServiceService, private authServe: AuthServiceService) {

  }

  ngOnInit() {
    this.uId = this._auth.userName;
    this.isAdmin = this.foodService.isAdmin;
    if (this.isAdmin) {
      this.foodService.getAllFoodItems().subscribe((res) => {
      this.items = res
      });
      this.foodService.getSubject().subscribe((data) => {
        this.items = data;


      });
    }
    else {
      this.foodService.getAllFoodItems().subscribe((res) => {
        this.items = res;
      }, (error: HttpErrorResponse) => {
        this.items = error;

        if (error instanceof Error) {
          console.log("cust errrrr cllient" + error)
        } else {
          console.log("customer server side" + error.message);
          console.log("customer server side" + error.statusText);

        }
      }
      );

      this.foodService.getSubject().subscribe((data) => {
        this.items = data;
      },
        (error: HttpErrorResponse) => {
          this.items = error;
          if (error instanceof Error) {
            console.log("errrrr cllient" + error)
          } else {
            console.log("server side" + error.message);
          }
          console.log("get by id" + this.items.json)
        }
      );

    }

  }
  addToCart(menuItemId) {

    this.foodService.addToCart(menuItemId, this.uId);
  }

}

