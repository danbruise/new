import { Injectable, Output, EventEmitter } from '@angular/core';

import { Subject } from 'rxjs';

import { Router } from '@angular/router';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { AuthServiceService } from '../site/auth-service.service';
import { environment } from 'src/environments/environment';
import { item } from './movie-info/item';
import { CartServiceService } from '../booking/favorite-service.service';

@Injectable({
  providedIn: 'root'
})

export class MovieServiceService {

  private subject = new Subject<item[]>();
  isAdmin: boolean = false;
  addedToCart: boolean = false;
  cartAddedId: number;
  isLoggedIn: boolean = false;
  clickedOnAdd: boolean = false;


  items: any;
  constructor(private _httpClient: HttpClient, private cartService: CartServiceService, private router: Router) { }
  baseUrl: string = environment.baseUrl;

  getAllFoodItems(): any {

    if (localStorage.getItem('token')) {
     
      var headers = new HttpHeaders();
      headers.set('Content-type', 'Application/json');
      headers = headers.set("Authorization", 'Bearer ' + localStorage.getItem('token'));
      return this._httpClient.get<any>(this.baseUrl, { headers });
    } else {
      let username = 'default'
      let password = 'pwd'
      var headers = new HttpHeaders();
      headers = headers.set("Authorization", 'Basic ' + btoa(username + ':' + password));
      return this._httpClient.get<any>(this.baseUrl, { headers });
    }
  }

  getSubject(): Subject<item[]> {
    return this.subject;
  }

  getFoodItem(foodItemId: number): any {
    var headers = new HttpHeaders();
    headers.set('Content-type', 'Application/json');
    headers = headers.set("Authorization", 'Bearer ' + localStorage.getItem('token'));
    return this._httpClient.get<any>(this.baseUrl + "/" + foodItemId, { headers });
  }

  updateFoodItem(foodItem: item) {
    var headers = new HttpHeaders();
    headers.set('Content-type', 'Application/json');
    headers = headers.set("Authorization", 'Bearer ' + localStorage.getItem('token'));
    return this._httpClient.put<any>(this.baseUrl, foodItem, { headers });
  }

  addToCart(foodItemId: number, userId) {
    if (this.isLoggedIn) {
      this.cartService.addCart(foodItemId, userId).subscribe();
      this.addedToCart = true;
      this.cartAddedId = foodItemId;
    }
    else {
      this.addedToCart = true;
      this.cartAddedId = foodItemId;
      this.clickedOnAdd = true;
      this.router.navigate(['login'])
    }
  }
  removeFromCart(foodItemId: number, uId) {
    this.cartService.removeCart(uId, foodItemId).subscribe(
      (res) => {
        this.router.navigate(['cart']);
      }
    );
  }
}
